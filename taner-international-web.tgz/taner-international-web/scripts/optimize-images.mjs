// Generates responsive WebP + AVIF variants into public/img from source masters.
// Usage: node scripts/optimize-images.mjs <masters-dir>
import sharp from 'sharp'
import { mkdirSync, existsSync } from 'node:fs'
import { join } from 'node:path'

const src = process.argv[2]
const out = 'public/img'
mkdirSync(out, { recursive: true })

// semantic name -> unsplash id (all images: Unsplash License, illustrative stock photography)
const map = {
  'texture-concrete-steps': '1559755777-d224c95ce158',
  'amsterdam-canal-day': '1627964718300-fab24a8a85ce',
  'izmir-bay-aerial': '1719688550640-e27dda479c57',
  'izmir-clock-tower': '1701428588034-5893b2512a68',
  'brick-residential': '1673977597041-7e6512719d16',
  'black-concrete-building': '1616368498208-7c411641b7af',
  'building-under-construction': '1573918644828-9598c67e680c',
  'rebar-detail': '1530863506128-dc9eb5c3e0fc',
  'amsterdam-canal-night': '1605609075879-88e12425d47a',
  'solar-array': '1726795867801-63c0a37b80c6',
  'solar-aerial-parking': '1726866492047-7f9516558c6e',
  'concrete-curve-bw': '1555940556-38836cc3ef7c',
  'spiral-stairs-bw': '1611584464715-f2045c5f4663',
  'curved-staircase-white': '1654722439127-0645ad92650b',
  'minimal-staircase': '1601993957728-1e56ab70c5a8',
  'concrete-curve-light': '1630146694733-9d730e4ed310',
  'facade-grid-bw': '1720762256650-ea429f429226',
  'brutalist-bw': '1626196784565-94410c0017cd',
  'solar-building-aerial': '1780445392528-4895da4b2cb8',
  'arches-hallway': '1650233323933-53e20427e277',
}

const widths = [640, 1024, 1440]
for (const [name, id] of Object.entries(map)) {
  const file = join(src, `${id}.webp`)
  if (!existsSync(file)) { console.warn('missing', file); continue }
  const meta = await sharp(file).metadata()
  for (const w of widths) {
    if (w > meta.width) continue
    await sharp(file).resize({ width: w }).webp({ quality: 74, effort: 5 }).toFile(join(out, `${name}-${w}.webp`))
    if (w >= 1024) await sharp(file).resize({ width: w }).avif({ quality: 52, effort: 4 }).toFile(join(out, `${name}-${w}.avif`))
  }
  // tiny blurred placeholder
  const buf = await sharp(file).resize({ width: 24 }).blur(2).webp({ quality: 40 }).toBuffer()
  console.log(name, meta.width + 'x' + meta.height, 'lqip', buf.length)
}
console.log('done')
