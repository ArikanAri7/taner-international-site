// Generates public/data/land.bin: Int16 pairs [lat*100, lon*100] of grid points
// that fall on land. Used by the hero WebGL scene (dot-globe). Source: world-atlas (Natural Earth 110m).
import { readFileSync, mkdirSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import * as topojson from 'topojson-client'

const require = createRequire(import.meta.url)
const land = JSON.parse(readFileSync(require.resolve('world-atlas/land-110m.json'), 'utf8'))
const geo = topojson.feature(land, land.objects.land)

// Collect rings
const rings = []
for (const f of geo.features) {
  const g = f.geometry
  const polys = g.type === 'Polygon' ? [g.coordinates] : g.coordinates
  for (const poly of polys) for (const ring of poly) rings.push(ring)
}

function inRing(ring, x, y) {
  let inside = false
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1]
    const intersect = (yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi
    if (intersect) inside = !inside
  }
  return inside
}
function onLand(lon, lat) {
  let c = 0
  for (const r of rings) if (inRing(r, lon, lat)) c++
  return c % 2 === 1
}

const pts = []
// Dense region: Europe, Mediterranean, Anatolia, Caucasus
const dense = { lon0: -28, lon1: 62, lat0: 18, lat1: 76, step: 0.55 }
for (let lat = dense.lat0; lat <= dense.lat1; lat += dense.step) {
  const row = lat + (Math.round((lat - dense.lat0) / dense.step) % 2) * 0 // keep aligned
  for (let lon = dense.lon0; lon <= dense.lon1; lon += dense.step) {
    const jl = lon + (Math.round((row - dense.lat0) / dense.step) % 2 ? dense.step / 2 : 0)
    if (onLand(jl, row)) pts.push([row, jl])
  }
}
// Sparse rest of the world
const sparse = 1.6
for (let lat = -84; lat <= 84; lat += sparse) {
  for (let lon = -180; lon < 180; lon += sparse) {
    if (lon >= dense.lon0 && lon <= dense.lon1 && lat >= dense.lat0 && lat <= dense.lat1) continue
    const jl = lon + ((Math.round((lat + 84) / sparse) % 2) ? sparse / 2 : 0)
    if (onLand(jl, lat)) pts.push([lat, jl])
  }
}

const out = new Int16Array(pts.length * 2)
pts.forEach(([lat, lon], i) => { out[i * 2] = Math.round(lat * 100); out[i * 2 + 1] = Math.round(lon * 100) })
mkdirSync('public/data', { recursive: true })
writeFileSync('public/data/land.bin', Buffer.from(out.buffer))
console.log('points', pts.length, 'bytes', out.byteLength)
