// Renders public/img/europe-dots.png — a minimal dot map of Europe & Anatolia for section 03.
// Projection: plate carrée with standard parallel 48° (x scaled by cos 48°).
import sharp from 'sharp'
import { readFileSync } from 'node:fs'

const LON0 = -30, LON1 = 60, LAT0 = 33, LAT1 = 63
const K = Math.cos((48 * Math.PI) / 180)
const W = 2400
const H = Math.round(W * ((LAT1 - LAT0) / ((LON1 - LON0) * K)))
const buf = readFileSync('public/data/land.bin')
const i16 = new Int16Array(buf.buffer, buf.byteOffset, buf.byteLength / 2)

const sx = W / ((LON1 - LON0) * K)
const sy = H / (LAT1 - LAT0)
let circles = ''
let n = 0
for (let i = 0; i < i16.length; i += 2) {
  const lat = i16[i] / 100
  const lon = i16[i + 1] / 100
  if (lon < LON0 || lon > LON1 || lat < LAT0 || lat > LAT1) continue
  // only the dense grid (0.55° spacing) falls inside this window
  const x = (lon - LON0) * K * sx
  const y = (LAT1 - lat) * sy
  circles += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="2.3"/>`
  n++
}
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><g fill="#f5f3ee">${circles}</g></svg>`
await sharp(Buffer.from(svg)).png({ compressionLevel: 9 }).toFile('public/img/europe-dots.png')
await sharp(Buffer.from(svg)).resize({ width: 1200 }).png({ compressionLevel: 9 }).toFile('public/img/europe-dots-1200.png')
console.log('dots', n, `${W}x${H}`, 'aspect', (W / H).toFixed(3))
