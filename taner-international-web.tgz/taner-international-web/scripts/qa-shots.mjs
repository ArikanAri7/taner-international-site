// Headless QA: serves dist/, captures screenshots at three viewports, logs console errors.
// Usage: node scripts/qa-shots.mjs [outDir]
import { chromium } from 'playwright'
import { createServer } from 'node:http'
import { readFile, stat, mkdir } from 'node:fs/promises'
import { join, extname } from 'node:path'

const out = process.argv[2] || 'qa'
await mkdir(out, { recursive: true })
const root = 'dist'
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.webp': 'image/webp', '.avif': 'image/avif', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.bin': 'application/octet-stream', '.json': 'application/json' }
const server = createServer(async (req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname)
  if (p === '/') p = '/index.html'
  try {
    const f = join(root, p)
    await stat(f)
    res.writeHead(200, { 'content-type': types[extname(f)] || 'application/octet-stream' })
    res.end(await readFile(f))
  } catch {
    res.writeHead(404)
    res.end()
  }
})
await new Promise((r) => server.listen(4173, r))

const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] })
const viewports = { desktop: { width: 1440, height: 900 }, tablet: { width: 834, height: 1112 }, mobile: { width: 390, height: 844 } }
const lang = process.env.LANG_ || 'tr'
for (const [name, vp] of Object.entries(viewports)) {
  const ctx = await browser.newContext({ viewport: vp, deviceScaleFactor: 1, isMobile: name === 'mobile', hasTouch: name === 'mobile' })
  const page = await ctx.newPage()
  const errors = []
  page.on('console', (m) => (m.type() === 'error' || m.type() === 'warning') && errors.push(`[${m.type()}] ${m.text()}`))
  page.on('response', (r) => r.status() >= 400 && errors.push('[' + r.status() + '] ' + r.url()))
  page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}`))
  await page.goto(`http://localhost:4173/?lang=${lang}`, { waitUntil: 'networkidle' })
  await page.mouse.move(vp.width * 0.4, vp.height * 0.55)
  await page.waitForTimeout(1800)
  await page.screenshot({ path: `${out}/${name}-hero.png` })
  // section-by-section viewport captures (reflects real scrolling; reveals + lazy images fire)
  const ids = ['grup', 'hollanda-turkiye', 'faaliyet-alanlari', 'yatirim', 'mimari', 'enerji', 'hakkimizda', 'iletisim']
  const h = await page.evaluate(() => document.body.scrollHeight)
  for (const id of ids) {
    await page.evaluate((i) => document.getElementById(i)?.scrollIntoView({ behavior: 'instant', block: 'start' }), id)
    await page.waitForTimeout(1600)
    await page.screenshot({ path: `${out}/${name}-${id}.png` })
    if (name === 'desktop') {
      await page.evaluate(() => window.scrollBy(0, window.innerHeight * 0.9))
      await page.waitForTimeout(1200)
      await page.screenshot({ path: `${out}/${name}-${id}-2.png` })
    }
  }
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight))
  await page.waitForTimeout(1200)
  await page.screenshot({ path: `${out}/${name}-footer.png` })
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth)
  console.log(name, 'height', h, 'horizontal-overflow', overflow)
  if (errors.length) console.log(name, 'console:', errors.slice(0, 10))
  await ctx.close()
}
await browser.close()
server.close()
