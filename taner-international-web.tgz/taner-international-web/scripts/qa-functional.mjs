// Functional QA: language switching, metadata, links, nav, reduced motion, no-WebGL fallback.
import { chromium } from 'playwright'
import { createServer } from 'node:http'
import { readFile, stat } from 'node:fs/promises'
import { join, extname } from 'node:path'

const root = 'dist'
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.webp': 'image/webp', '.avif': 'image/avif', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.bin': 'application/octet-stream' }
const server = createServer(async (req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname)
  if (p === '/') p = '/index.html'
  try {
    const f = join(root, p)
    await stat(f)
    res.writeHead(200, { 'content-type': types[extname(f)] || 'application/octet-stream' })
    res.end(await readFile(f))
  } catch {
    res.writeHead(404)
    res.end()
  }
})
await new Promise((r) => server.listen(4174, r))
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] })
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })
const errors = []
page.on('pageerror', (e) => errors.push(e.message))
await page.goto('http://localhost:4174/', { waitUntil: 'networkidle' })

const snapshot = async () => ({
  lang: await page.evaluate(() => document.documentElement.lang),
  title: await page.title(),
  desc: await page.$eval('meta[name="description"]', (m) => m.content),
  canonical: await page.$eval('link[rel="canonical"]', (l) => l.href),
  nav: await page.$$eval('.nav__links a', (as) => as.map((a) => a.textContent.trim())),
  h2: await page.$$eval('main h2', (hs) => hs.map((h) => h.textContent.trim()).slice(0, 3)),
  cta: await page.$eval('.hero .btn', (b) => b.textContent.trim()),
  alt: await page.$eval('#grup img', (i) => i.alt),
  footer: await page.$eval('.footer__bottom', (f) => f.textContent.trim().slice(0, 60)),
})
console.log('DEFAULT', await snapshot())
for (const l of ['en', 'nl', 'tr']) {
  await page.click(`.nav .lang__btn[lang="${l}"]`)
  await page.waitForTimeout(200)
  console.log(l.toUpperCase(), await snapshot())
}
// persistence
await page.click('.nav .lang__btn[lang="nl"]')
await page.reload({ waitUntil: 'networkidle' })
console.log('after reload lang =', await page.evaluate(() => document.documentElement.lang))
await page.goto('http://localhost:4174/?lang=en', { waitUntil: 'networkidle' })
console.log('?lang=en →', await page.evaluate(() => document.documentElement.lang))
await page.click('.nav .lang__btn[lang="tr"]')

// links
const links = await page.$$eval('a[href]', (as) => as.map((a) => a.getAttribute('href')))
const anchors = links.filter((h) => h.startsWith('#'))
const missing = []
for (const a of new Set(anchors)) {
  const ok = await page.evaluate((id) => !!document.getElementById(id), a.slice(1))
  if (!ok) missing.push(a)
}
console.log('anchor links', new Set(anchors).size, 'missing targets', missing)
console.log('external', [...new Set(links.filter((h) => h.startsWith('http')))])
console.log('mailto', [...new Set(links.filter((h) => h.startsWith('mailto')))])

// heading hierarchy
console.log('headings', await page.$$eval('h1,h2,h3', (hs) => hs.map((h) => h.tagName).join(' ').slice(0, 120)))
console.log('h1 text', await page.$eval('h1', (h) => h.textContent))
console.log('images without alt attr', await page.$$eval('img', (is) => is.filter((i) => !i.hasAttribute('alt')).length))

// keyboard: tab to first nav link, open mobile menu at small width
await page.setViewportSize({ width: 390, height: 844 })
await page.click('.nav__burger')
await page.waitForTimeout(800)
console.log('mobile menu open', await page.$eval('#mobile-menu', (m) => m.classList.contains('is-open')), 'links', await page.$$eval('#mobile-menu a', (as) => as.length))
await page.keyboard.press('Escape')
await page.waitForTimeout(300)
console.log('menu closed by Esc', !(await page.$eval('#mobile-menu', (m) => m.classList.contains('is-open'))))

// reduced motion: content visible without animation
const ctx2 = await browser.newContext({ reducedMotion: 'reduce', viewport: { width: 1440, height: 900 } })
const p2 = await ctx2.newPage()
await p2.goto('http://localhost:4174/', { waitUntil: 'networkidle' })
console.log('reduced-motion class', await p2.evaluate(() => document.documentElement.classList.contains('reduced-motion')),
  'reveal opacity', await p2.$eval('#grup [data-reveal]', (el) => getComputedStyle(el).opacity))
await ctx2.close()

// no WebGL: fallback renders
const ctx3 = await browser.newContext({ viewport: { width: 1440, height: 900 } })
await ctx3.addInitScript(() => { const o = HTMLCanvasElement.prototype.getContext; HTMLCanvasElement.prototype.getContext = function (t, ...a) { return /webgl/.test(t) ? null : o.call(this, t, ...a) } })
const p3 = await ctx3.newPage()
await p3.goto('http://localhost:4174/', { waitUntil: 'networkidle' })
await p3.waitForTimeout(800)
console.log('fallback present', !!(await p3.$('.hero__fallback')), 'canvas present', !!(await p3.$('.hero canvas')))
await p3.screenshot({ path: process.argv[2] + '/fallback-hero.png' })
await ctx3.close()

console.log('page errors', errors)
await browser.close()
server.close()
