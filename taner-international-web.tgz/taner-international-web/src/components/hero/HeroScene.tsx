import { Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import {
  AdditiveBlending,
  BackSide,
  BufferAttribute,
  BufferGeometry,
  Color,
  Group,
  Line,
  LineBasicMaterial,
  Mesh,
  Points,
  ShaderMaterial,
  Vector3,
} from 'three'
import { latLonToVec, loadLand, routePoints, NL, TR, DEG } from './geo'

export interface SceneShared {
  /** pointer in NDC-ish units (-1..1) */
  pointer: { x: number; y: number }
  /** 0..1 progress of the hero scrolling out of view */
  scroll: { v: number }
  /** receives projected pixel positions of the two anchors each frame */
  onProject?: (nl: { x: number; y: number; z: number }, tr: { x: number; y: number; z: number }) => void
}

interface Props {
  shared: SceneShared
  quality: 'high' | 'low'
  active: boolean
  reduced: boolean
}

const GOLD = new Color('#b49a62')
const R = 2.75

/* ---------------------------------------------------------------- shaders */
const pointsVert = /* glsl */ `
  attribute float aRand;
  attribute float aGold;
  uniform float uTime;
  uniform float uSize;
  uniform float uPixelRatio;
  varying float vAlpha;
  varying float vGold;
  void main() {
    vec4 world = modelMatrix * vec4(position, 1.0);
    vec3 n = normalize(mat3(modelMatrix) * normalize(position));
    vec3 toCam = normalize(cameraPosition - world.xyz);
    float facing = dot(n, toCam);
    vec4 mv = viewMatrix * world;
    gl_Position = projectionMatrix * mv;
    float tw = 0.75 + 0.25 * sin(uTime * (0.6 + aRand * 0.8) + aRand * 6.28318);
    vAlpha = smoothstep(-0.05, 0.35, facing) * tw;
    vGold = aGold;
    gl_PointSize = uSize * uPixelRatio * (1.0 + aGold * 0.7) * (10.0 / -mv.z);
  }
`
const pointsFrag = /* glsl */ `
  precision highp float;
  uniform vec3 uColor;
  uniform vec3 uGold;
  varying float vAlpha;
  varying float vGold;
  void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = length(c);
    float a = 1.0 - smoothstep(0.32, 0.5, d);
    vec3 col = mix(uColor, uGold, vGold);
    gl_FragColor = vec4(col, a * vAlpha * (0.55 + 0.45 * vGold));
    if (gl_FragColor.a < 0.01) discard;
  }
`
const rimVert = /* glsl */ `
  varying vec3 vN;
  varying vec3 vV;
  void main() {
    vec4 world = modelMatrix * vec4(position, 1.0);
    vN = normalize(mat3(modelMatrix) * normal);
    vV = normalize(cameraPosition - world.xyz);
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`
const rimFrag = /* glsl */ `
  precision highp float;
  uniform vec3 uColor;
  varying vec3 vN;
  varying vec3 vV;
  void main() {
    float f = pow(1.0 - max(dot(vN, vV), 0.0), 3.2);
    gl_FragColor = vec4(uColor, f * 0.55);
  }
`

/* ---------------------------------------------------------------- land points */
function LandPoints({ data, quality, route }: { data: Float32Array; quality: 'high' | 'low'; route: Vector3[] }) {
  const ref = useRef<Points>(null)
  const geometry = useMemo(() => {
    const n = data.length / 2
    const stride = quality === 'low' ? 2 : 1
    const count = Math.ceil(n / stride)
    const pos = new Float32Array(count * 3)
    const rand = new Float32Array(count)
    const gold = new Float32Array(count)
    const v = new Vector3()
    // unit vectors of the route for corridor tinting
    const routeUnit = route.map((p) => p.clone().normalize())
    let j = 0
    for (let i = 0; i < n; i += stride) {
      const lat = data[i * 2]
      const lon = data[i * 2 + 1]
      latLonToVec(lat, lon, R, v)
      pos[j * 3] = v.x
      pos[j * 3 + 1] = v.y
      pos[j * 3 + 2] = v.z
      rand[j] = Math.random()
      // angular distance to the route corridor (coarse sampling for speed)
      let best = 10
      const u = v.clone().normalize()
      for (let k = 0; k < routeUnit.length; k += 8) {
        const a = u.angleTo(routeUnit[k])
        if (a < best) best = a
      }
      gold[j] = Math.max(0, 1 - best / (3.2 * DEG)) ** 1.5
      j++
    }
    const g = new BufferGeometry()
    g.setAttribute('position', new BufferAttribute(pos, 3))
    g.setAttribute('aRand', new BufferAttribute(rand, 1))
    g.setAttribute('aGold', new BufferAttribute(gold, 1))
    return g
  }, [data, quality, route])

  const material = useMemo(
    () =>
      new ShaderMaterial({
        vertexShader: pointsVert,
        fragmentShader: pointsFrag,
        transparent: true,
        depthWrite: false,
        uniforms: {
          uTime: { value: 0 },
          uSize: { value: quality === 'low' ? 2.4 : 2.0 },
          uPixelRatio: { value: 1 },
          uColor: { value: new Color('#c9c4b8') },
          uGold: { value: GOLD.clone() },
        },
      }),
    [quality],
  )
  const dpr = useThree((s) => s.viewport.dpr)
  useEffect(() => {
    material.uniforms.uPixelRatio.value = dpr
  }, [dpr, material])
  useEffect(() => () => {
    geometry.dispose()
    material.dispose()
  }, [geometry, material])
  useFrame((_, dt) => {
    material.uniforms.uTime.value += dt
  })
  return <points ref={ref} geometry={geometry} material={material} />
}

/* ---------------------------------------------------------------- route */
function Route({ points, reduced }: { points: Vector3[]; reduced: boolean }) {
  const geometry = useMemo(() => new BufferGeometry().setFromPoints(points), [points])
  const travellers = useRef<Points>(null)
  const tGeo = useMemo(() => {
    const g = new BufferGeometry()
    g.setAttribute('position', new BufferAttribute(new Float32Array(3 * 3), 3))
    return g
  }, [])
  useEffect(() => () => {
    geometry.dispose()
    tGeo.dispose()
  }, [geometry, tGeo])
  const t = useRef(0)
  useFrame((_, dt) => {
    if (reduced) return
    t.current += dt * 0.11
    const attr = tGeo.attributes.position as BufferAttribute
    const n = points.length - 1
    for (let i = 0; i < 3; i++) {
      const phase = (t.current + i * 0.33) % 1
      const e = phase < 0.5 ? 2 * phase * phase : 1 - Math.pow(-2 * phase + 2, 2) / 2 // easeInOutQuad
      const f = e * n
      const k = Math.floor(f)
      const a = points[Math.min(k, n)]
      const b = points[Math.min(k + 1, n)]
      const r = f - k
      attr.setXYZ(i, a.x + (b.x - a.x) * r, a.y + (b.y - a.y) * r, a.z + (b.z - a.z) * r)
    }
    attr.needsUpdate = true
  })
  const line = useMemo(() => new Line(geometry, new LineBasicMaterial({ color: GOLD, transparent: true, opacity: 0.9 })), [geometry])
  useEffect(() => () => (line.material as LineBasicMaterial).dispose(), [line])
  return (
    <group>
      <primitive object={line} />
      <points ref={travellers} geometry={tGeo}>
        <pointsMaterial color="#f3e6c4" size={0.06} sizeAttenuation transparent opacity={0.95} blending={AdditiveBlending} depthWrite={false} />
      </points>
    </group>
  )
}

function Marker({ vec, reduced }: { vec: Vector3; reduced: boolean }) {
  const ring = useRef<Mesh>(null)
  const group = useRef<Group>(null)
  useEffect(() => {
    if (!group.current) return
    group.current.position.copy(vec).multiplyScalar(1.004)
    group.current.lookAt(vec.clone().multiplyScalar(2))
  }, [vec])
  useFrame(({ clock }) => {
    if (!ring.current || reduced) return
    const s = 1 + 0.5 * ((clock.elapsedTime * 0.6) % 1)
    ring.current.scale.setScalar(s)
    const m = ring.current.material as { opacity: number }
    m.opacity = 0.6 * (1 - ((clock.elapsedTime * 0.6) % 1))
  })
  return (
    <group ref={group}>
      <mesh>
        <circleGeometry args={[0.022, 24]} />
        <meshBasicMaterial color={GOLD} />
      </mesh>
      <mesh ref={ring}>
        <ringGeometry args={[0.06, 0.066, 48]} />
        <meshBasicMaterial color={GOLD} transparent opacity={0.6} depthWrite={false} />
      </mesh>
    </group>
  )
}

function Ring({ radius, tilt, color, opacity }: { radius: number; tilt: [number, number, number]; color: string; opacity: number }) {
  const geometry = useMemo(() => {
    const pts: Vector3[] = []
    for (let i = 0; i <= 256; i++) {
      const a = (i / 256) * Math.PI * 2
      pts.push(new Vector3(Math.cos(a) * radius, 0, Math.sin(a) * radius))
    }
    return new BufferGeometry().setFromPoints(pts)
  }, [radius])
  const line = useMemo(
    () => new Line(geometry, new LineBasicMaterial({ color, transparent: true, opacity })),
    [geometry, color, opacity],
  )
  useEffect(() => () => {
    geometry.dispose()
    ;(line.material as LineBasicMaterial).dispose()
  }, [geometry, line])
  return (
    <group rotation={tilt}>
      <primitive object={line} />
    </group>
  )
}

/* ---------------------------------------------------------------- globe */
function Globe({ data, quality, reduced, shared }: { data: Float32Array; quality: 'high' | 'low'; reduced: boolean; shared: SceneShared }) {
  const group = useRef<Group>(null)
  const { nlVec, trVec, route } = useMemo(() => {
    const a = latLonToVec(NL.lat, NL.lon, R)
    const b = latLonToVec(TR.lat, TR.lon, R)
    return { nlVec: a, trVec: b, route: routePoints(a.clone().normalize(), b.clone().normalize(), R, 128, 0.15) }
  }, [])

  // Orientation: bring a point south-east of the two countries to face the camera, so that
  // Europe/Anatolia sits in the upper-left quadrant of the visible sphere.
  const baseRot = useMemo(() => ({ x: 24 * DEG, y: -34 * DEG }), [])
  const tmp = useMemo(() => new Vector3(), [])
  const tmp2 = useMemo(() => new Vector3(), [])

  useFrame(({ clock, camera }) => {
    const g = group.current
    if (!g) return
    const t = clock.elapsedTime
    const idle = reduced ? 0 : Math.sin(t * 0.12) * 0.035
    g.rotation.x = baseRot.x + (reduced ? 0 : Math.sin(t * 0.09) * 0.02)
    g.rotation.y = baseRot.y + idle
    if (shared.onProject) {
      g.updateWorldMatrix(true, false)
      tmp.copy(nlVec).applyMatrix4(g.matrixWorld).project(camera)
      tmp2.copy(trVec).applyMatrix4(g.matrixWorld).project(camera)
      shared.onProject(tmp, tmp2)
    }
  })

  return (
    <group ref={group}>
      {/* occluder body with restrained metallic sheen */}
      <mesh>
        <sphereGeometry args={[R * 0.993, 96, 96]} />
        <meshStandardMaterial color="#0c0c0c" roughness={0.58} metalness={0.42} />
      </mesh>
      {quality === 'high' && (
        <mesh>
          <sphereGeometry args={[R * 1.004, 96, 96]} />
          <shaderMaterial
            vertexShader={rimVert}
            fragmentShader={rimFrag}
            uniforms={{ uColor: { value: GOLD.clone() } }}
            transparent
            depthWrite={false}
            side={BackSide}
          />
        </mesh>
      )}
      <LandPoints data={data} quality={quality} route={route} />
      <Route points={route} reduced={reduced} />
      <Marker vec={nlVec} reduced={reduced} />
      <Marker vec={trVec} reduced={reduced} />
      {/* architectural geometry: fine orbital rings */}
      <Ring radius={R * 1.22} tilt={[72 * DEG, 0, 18 * DEG]} color="#b49a62" opacity={0.28} />
      <Ring radius={R * 1.36} tilt={[80 * DEG, 0, -12 * DEG]} color="#f5f3ee" opacity={0.07} />
      <Ring radius={R * 1.06} tilt={[62 * DEG, 0, 40 * DEG]} color="#f5f3ee" opacity={0.05} />
    </group>
  )
}

/* ---------------------------------------------------------------- camera rig */
function Rig({ shared, reduced }: { shared: SceneShared; reduced: boolean }) {
  const { camera, viewport } = useThree()
  const target = useRef({ x: 0, y: 0 })
  const look = useMemo(() => new Vector3(), [])
  useFrame((_, dt) => {
    const k = 1 - Math.pow(0.0005, Math.min(dt, 0.05))
    if (!reduced) {
      target.current.x += (shared.pointer.x - target.current.x) * k
      target.current.y += (shared.pointer.y - target.current.y) * k
    }
    const s = shared.scroll.v
    const portrait = viewport.width / viewport.height < 1.05
    const mobile = portrait
    // The globe sits at the origin; the camera looks at a point up-left of it so the sphere
    // occupies the lower-right of the frame and Europe/Anatolia sits near the upper centre.
    const dist = (mobile ? 12.6 : 10.6) + s * 1.6
    const lx = mobile ? -0.55 : -2.5
    const ly = mobile ? -0.75 : 1.75
    camera.position.set(lx + target.current.x * 0.4, ly + target.current.y * 0.28 - s * 0.8, dist)
    look.set(lx, ly - s * 0.8, 0)
    camera.lookAt(look)
  })
  return null
}

function Scene({ shared, quality, reduced }: { shared: SceneShared; quality: 'high' | 'low'; reduced: boolean }) {
  const [data, setData] = useState<Float32Array | null>(null)
  useEffect(() => {
    let alive = true
    loadLand().then((d) => alive && setData(d)).catch(() => {})
    return () => {
      alive = false
    }
  }, [])
  if (!data) return null
  return (
    <>
      <ambientLight intensity={0.22} />
      <directionalLight position={[-6, 7, 4]} intensity={2.6} color="#fff6e6" />
      <directionalLight position={[5, -3, -4]} intensity={0.5} color="#b49a62" />
      <Globe data={data} quality={quality} reduced={reduced} shared={shared} />
      <Rig shared={shared} reduced={reduced} />
    </>
  )
}

export default function HeroScene({ shared, quality, active, reduced }: Props) {
  return (
    <Canvas
      dpr={quality === 'high' ? [1, 1.75] : [1, 1.25]}
      camera={{ fov: 32, near: 0.1, far: 60, position: [-1.5, 1, 8.2] }}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance', stencil: false }}
      frameloop={active ? 'always' : 'never'}
      onCreated={({ gl }) => gl.setClearColor(0x000000, 0)}
      style={{ position: 'absolute', inset: 0 }}
    >
      <Suspense fallback={null}>
        <Scene shared={shared} quality={quality} reduced={reduced} />
      </Suspense>
    </Canvas>
  )
}

