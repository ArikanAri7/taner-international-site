import { Vector3 } from 'three'

export const DEG = Math.PI / 180

/** lat/lon (degrees) → unit-sphere vector. lon 0 / lat 0 faces +Z. */
export function latLonToVec(lat: number, lon: number, r = 1, out = new Vector3()): Vector3 {
  const la = lat * DEG
  const lo = lon * DEG
  return out.set(r * Math.cos(la) * Math.sin(lo), r * Math.sin(la), r * Math.cos(la) * Math.cos(lo))
}

/** Verified geography used in the scene: the two countries, with İzmir as the Turkish anchor. */
export const NL = { lat: 52.37, lon: 4.9 } // Netherlands (Amsterdam coordinates as the country anchor)
export const TR = { lat: 38.42, lon: 27.14 } // İzmir, Türkiye

/** Great-circle route between two unit vectors, lifted off the surface in the middle. */
export function routePoints(a: Vector3, b: Vector3, r: number, segments = 128, lift = 0.16): Vector3[] {
  const pts: Vector3[] = []
  const angle = a.angleTo(b)
  for (let i = 0; i <= segments; i++) {
    const t = i / segments
    const p = new Vector3().copy(a).multiplyScalar(Math.sin((1 - t) * angle)).add(
      new Vector3().copy(b).multiplyScalar(Math.sin(t * angle)),
    )
    p.divideScalar(Math.sin(angle) || 1).normalize()
    const h = r * (1 + lift * Math.sin(Math.PI * t) * (angle / 0.5))
    pts.push(p.multiplyScalar(h))
  }
  return pts
}

/** Loads public/data/land.bin (Int16 lat*100, lon*100 pairs). */
export async function loadLand(): Promise<Float32Array> {
  const res = await fetch(`${import.meta.env.BASE_URL}data/land.bin`)
  const buf = await res.arrayBuffer()
  const i16 = new Int16Array(buf)
  const out = new Float32Array(i16.length)
  for (let i = 0; i < i16.length; i++) out[i] = i16[i] / 100
  return out
}
