import { lazy, Suspense, useEffect, useMemo, useRef, useState, Component, type ReactNode } from 'react'
import { useT } from '../../i18n'
import { Headline } from './Headline'
import { useReducedMotion, useMediaQuery } from '../../hooks/useReducedMotion'
import type { SceneShared } from './HeroScene'

const HeroScene = lazy(() => import('./HeroScene'))

function webglAvailable(): boolean {
  try {
    const c = document.createElement('canvas')
    return !!(c.getContext('webgl2') || c.getContext('webgl'))
  } catch {
    return false
  }
}

class SceneBoundary extends Component<{ fallback: ReactNode; children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() {
    return { failed: true }
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children
  }
}

/** Static fallback: gradient field with the same gold route drawn in SVG. */
function Fallback({ label }: { label: string }) {
  return (
    <div className="hero__fallback" role="img" aria-label={label}>
      <svg viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <radialGradient id="fb-g" cx="78%" cy="72%" r="45%">
            <stop offset="0" stopColor="#1b1b1b" />
            <stop offset="1" stopColor="#080808" stopOpacity="0" />
          </radialGradient>
        </defs>
        <circle cx="780" cy="430" r="330" fill="url(#fb-g)" />
        <circle cx="780" cy="430" r="330" fill="none" stroke="#b49a62" strokeOpacity="0.25" />
        <ellipse cx="780" cy="430" rx="400" ry="90" fill="none" stroke="#b49a62" strokeOpacity="0.18" transform="rotate(-18 780 430)" />
        <path d="M612 262 C 690 190, 800 230, 846 330" fill="none" stroke="#b49a62" strokeWidth="1.4" />
        <circle cx="612" cy="262" r="3.5" fill="#b49a62" />
        <circle cx="846" cy="330" r="3.5" fill="#b49a62" />
      </svg>
    </div>
  )
}

export function Hero() {
  const t = useT()
  const areaRef = useRef<HTMLElement>(null)
  const pinNl = useRef<HTMLDivElement>(null)
  const pinTr = useRef<HTMLDivElement>(null)
  const reduced = useReducedMotion()
  const smallScreen = useMediaQuery('(max-width: 900px)')
  const coarse = useMediaQuery('(pointer: coarse)')
  const [canvasOk] = useState(() => webglAvailable())
  const [active, setActive] = useState(true)
  const [mounted, setMounted] = useState(false)

  const shared = useMemo<SceneShared>(() => {
    const s: SceneShared = { pointer: { x: 0, y: 0 }, scroll: { v: 0 } }
    s.onProject = (nl, tr) => {
      const el = areaRef.current
      if (!el) return
      const w = el.clientWidth
      const h = el.clientHeight
      const place = (pin: HTMLDivElement | null, v: { x: number; y: number; z: number }) => {
        if (!pin) return
        const x = (v.x * 0.5 + 0.5) * w
        const y = (-v.y * 0.5 + 0.5) * h
        pin.style.left = `${x}px`
        pin.style.top = `${y}px`
        pin.classList.toggle('is-visible', v.z < 1 && x > 0 && x < w && y > 0 && y < h)
      }
      place(pinNl.current, nl)
      place(pinTr.current, tr)
    }
    return s
  }, [])

  // Defer mounting the 3D bundle slightly so the headline paints first.
  useEffect(() => {
    const id = window.setTimeout(() => setMounted(true), 120)
    return () => window.clearTimeout(id)
  }, [])

  // Pointer + scroll feeds for the scene; pause rendering when the hero is off screen.
  useEffect(() => {
    const el = areaRef.current
    if (!el) return
    const onMove = (e: PointerEvent) => {
      if (e.pointerType === 'touch') return
      const r = el.getBoundingClientRect()
      shared.pointer.x = ((e.clientX - r.left) / r.width) * 2 - 1
      shared.pointer.y = -(((e.clientY - r.top) / r.height) * 2 - 1)
    }
    const onLeave = () => {
      shared.pointer.x = 0
      shared.pointer.y = 0
    }
    const onScroll = () => {
      shared.scroll.v = Math.min(1, Math.max(0, window.scrollY / Math.max(1, el.offsetHeight)))
    }
    el.addEventListener('pointermove', onMove, { passive: true })
    el.addEventListener('pointerleave', onLeave)
    window.addEventListener('scroll', onScroll, { passive: true })
    const io = new IntersectionObserver(([entry]) => setActive(entry.isIntersecting), { threshold: 0.02 })
    io.observe(el)
    return () => {
      el.removeEventListener('pointermove', onMove)
      el.removeEventListener('pointerleave', onLeave)
      window.removeEventListener('scroll', onScroll)
      io.disconnect()
    }
  }, [shared])

  const quality: 'high' | 'low' = smallScreen || coarse ? 'low' : 'high'

  return (
    <section className="hero" id="top" ref={areaRef} aria-label="TANER INTERNATIONAL">
      <div className="hero__scene" aria-hidden="true">
        {canvasOk ? (
          <SceneBoundary fallback={<Fallback label={t.hero.sceneAlt} />}>
            {mounted && (
              <Suspense fallback={null}>
                <HeroScene shared={shared} quality={quality} active={active} reduced={reduced} />
              </Suspense>
            )}
          </SceneBoundary>
        ) : (
          <Fallback label={t.hero.sceneAlt} />
        )}
      </div>
      {canvasOk && (
        <div className="hero__labels" aria-hidden="true">
          <div className="hero__pin hero__pin--left" ref={pinNl}>
            <span>{t.hero.routeFrom}</span>
            <i />
          </div>
          <div className="hero__pin hero__pin--right" ref={pinTr}>
            <i />
            <span>{t.hero.routeTo}</span>
          </div>
        </div>
      )}
      <div className="hero__veil" aria-hidden="true" />

      <div className="hero__content">
        <p className="label hero__eyebrow">{t.hero.eyebrow}</p>
        <Headline areaRef={areaRef} />
        <div className="hero__row">
          <p className="hero__statement">{t.hero.statement}</p>
          <div className="hero__actions">
            <a className="scroll-cue" href="#grup">
              <span className="scroll-cue__line" aria-hidden="true" />
              {t.hero.scroll}
            </a>
            <a className="btn btn--gold" href="#iletisim">
              <span>{t.hero.cta}</span>
              <svg className="arrow" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M3 13 13 3M5 3h8v8" stroke="currentColor" strokeWidth="1.4" />
              </svg>
            </a>
          </div>
        </div>
      </div>
      {!canvasOk && <p className="sr-only">{t.status.noWebgl}</p>}
    </section>
  )
}
