import { useEffect, useRef, type RefObject } from 'react'
import { lerp, clamp, isCoarsePointer } from '../../lib/motion'
import { useReducedMotion } from '../../hooks/useReducedMotion'
import { asset } from '../../lib/asset'

const LINES = ['TANER', 'INTERNATIONAL']

interface Props {
  /** element whose pointer events drive the effect (the whole hero) */
  areaRef: RefObject<HTMLElement | null>
}

function Letters({ text, layer }: { text: string; layer: 'base' | 'tex' | 'sheen' }) {
  return (
    <span className="headline__line" aria-hidden={layer !== 'base' ? true : undefined}>
      <span className="headline__word">
        {text.split('').map((c, i) => (
          <span className="ch" key={i} data-ch={layer === 'base' ? '' : undefined}>
            {c}
          </span>
        ))}
      </span>
    </span>
  )
}

/**
 * Monumental TANER INTERNATIONAL wordmark.
 * The accessible text lives in a visually-hidden <h1>; the three visual layers are
 * aria-hidden and driven by CSS custom properties updated from pointer movement:
 *  – base: warm-white text with a metallic radial highlight following the cursor
 *  – tex:  concrete texture clipped to the glyphs, revealed through a radial mask
 *  – sheen: a thin gold light-band sweeping across the letters
 * Individual letters are displaced away from the cursor; the whole block tilts slightly.
 */
export function Headline({ areaRef }: Props) {
  const rootRef = useRef<HTMLDivElement>(null)
  const innerRef = useRef<HTMLSpanElement>(null)
  const reduced = useReducedMotion()

  useEffect(() => {
    const root = rootRef.current
    const inner = innerRef.current
    const area = areaRef.current
    if (!root || !inner || !area) return

    const letters = Array.from(root.querySelectorAll<HTMLElement>('.headline__base .ch'))
    const mirrors = [
      Array.from(root.querySelectorAll<HTMLElement>('.headline__tex .ch')),
      Array.from(root.querySelectorAll<HTMLElement>('.headline__sheen .ch')),
    ]
    let rects: { x: number; y: number }[] = []
    let box = root.getBoundingClientRect()

    const all = [letters, ...mirrors]
    const measure = () => {
      box = root.getBoundingClientRect()
      rects = letters.map((el) => {
        const r = el.getBoundingClientRect()
        return { x: r.left + r.width / 2 - box.left, y: r.top + r.height / 2 - box.top }
      })
      // Give every letter the same background box (the whole wordmark) so gradients are continuous.
      for (const layer of all) {
        for (let i = 0; i < layer.length; i++) {
          const el = layer[i]
          const r = el.getBoundingClientRect()
          const isTex = layer === mirrors[0]
          el.style.backgroundSize = isTex ? `${box.width * 1.1}px auto` : `${box.width}px ${box.height}px`
          el.style.backgroundPosition = `${-(r.left - box.left)}px ${-(r.top - box.top)}px`
        }
      }
    }
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(root)
    window.addEventListener('scroll', measure, { passive: true })

    const coarse = isCoarsePointer()
    const target = { x: box.width * 0.35, y: box.height * 0.5, active: coarse ? 0.65 : 0 }
    const cur = { x: target.x, y: target.y, active: 0 }
    let raf = 0
    let running = true
    let t0 = performance.now()

    const onMove = (e: PointerEvent) => {
      if (e.pointerType === 'touch') return
      target.x = e.clientX - box.left
      target.y = e.clientY - box.top
      target.active = 1
      root.classList.add('is-active')
    }
    const onLeave = () => {
      target.active = 0
      root.classList.remove('is-active')
    }
    area.addEventListener('pointermove', onMove, { passive: true })
    area.addEventListener('pointerleave', onLeave)

    const radius = () => Math.max(160, box.width * 0.16)

    const frame = (now: number) => {
      if (!running) return
      const dt = Math.min(0.05, (now - t0) / 1000)
      t0 = now
      const k = 1 - Math.pow(0.001, dt) // frame-rate independent smoothing
      if (coarse) {
        // gentle autonomous drift for touch devices
        const s = now / 1000
        target.x = box.width * (0.5 + 0.38 * Math.sin(s * 0.35))
        target.y = box.height * (0.5 + 0.3 * Math.cos(s * 0.27))
      }
      cur.x = lerp(cur.x, target.x, k)
      cur.y = lerp(cur.y, target.y, k)
      cur.active = lerp(cur.active, target.active, k * 0.8)

      const mx = clamp((cur.x / box.width) * 100, -20, 120)
      const my = clamp((cur.y / box.height) * 100, -20, 120)
      root.style.setProperty('--mx', `${mx}%`)
      root.style.setProperty('--my', `${my}%`)
      root.style.setProperty('--sx', `${mx}%`)
      root.style.setProperty('--tx', `${50 + (mx - 50) * 0.2}%`)
      root.style.setProperty('--ty', `${50 + (my - 50) * 0.2}%`)
      root.style.setProperty('--reveal', String(cur.active * (coarse ? 0.6 : 0.9)))
      root.style.setProperty('--sheen', String(cur.active * (coarse ? 0.5 : 0.85)))

      if (!reduced && !coarse) {
        const rx = -((my - 50) / 50) * 1.6 * cur.active
        const ry = ((mx - 50) / 50) * 2.4 * cur.active
        inner.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`

        const R = radius()
        for (let i = 0; i < letters.length; i++) {
          const r = rects[i]
          if (!r) continue
          const dx = r.x - cur.x
          const dy = r.y - cur.y
          const d = Math.hypot(dx, dy) || 1
          const inf = Math.exp(-(d * d) / (R * R)) * cur.active
          const push = inf * Math.min(14, box.width * 0.012)
          const ox = (dx / d) * push
          const oy = (dy / d) * push * 0.7
          const rz = (dx / d) * inf * 1.6
          const style = `translate3d(${ox.toFixed(2)}px, ${oy.toFixed(2)}px, 0) rotate(${rz.toFixed(2)}deg)`
          letters[i].style.transform = style
          mirrors[0][i].style.transform = style
          mirrors[1][i].style.transform = style
        }
      }
      raf = requestAnimationFrame(frame)
    }
    raf = requestAnimationFrame(frame)

    return () => {
      running = false
      cancelAnimationFrame(raf)
      ro.disconnect()
      window.removeEventListener('scroll', measure)
      area.removeEventListener('pointermove', onMove)
      area.removeEventListener('pointerleave', onLeave)
    }
  }, [areaRef, reduced])

  return (
    <div className="headline" ref={rootRef} style={{ ['--tex-url' as string]: `url(${new URL(asset('img/texture-concrete-steps-1024.webp'), document.baseURI).href})` }}>
      <h1 className="sr-only">TANER INTERNATIONAL</h1>
      <span className="headline__inner" ref={innerRef} aria-hidden="true">
        <span className="headline__base">
          {LINES.map((l) => (
            <Letters key={l} text={l} layer="base" />
          ))}
        </span>
        <span className="headline__tex">
          {LINES.map((l) => (
            <Letters key={l} text={l} layer="tex" />
          ))}
        </span>
        <span className="headline__sheen">
          {LINES.map((l) => (
            <Letters key={l} text={l} layer="sheen" />
          ))}
        </span>
      </span>
    </div>
  )
}
