import { asset } from '../../lib/asset'
import { useT } from '../../i18n'

function Compass() {
  return (
    <svg className="compass" viewBox="0 0 200 200" fill="none" aria-hidden="true" data-spin>
      <circle cx="100" cy="100" r="96" stroke="currentColor" strokeOpacity="0.5" />
      <circle cx="100" cy="100" r="66" stroke="currentColor" strokeOpacity="0.35" strokeDasharray="2 5" />
      <circle cx="100" cy="100" r="30" stroke="currentColor" strokeOpacity="0.6" />
      <path d="M100 4v24M100 172v24M4 100h24M172 100h24" stroke="currentColor" />
      <path d="M100 70 112 100 100 130 88 100Z" fill="currentColor" fillOpacity="0.9" />
      <path d="M32 32l14 14M168 32l-14 14M32 168l14-14M168 168l-14-14" stroke="currentColor" strokeOpacity="0.5" />
    </svg>
  )
}

export function Investment() {
  const t = useT()
  return (
    <section className="section theme-dark invest" id="yatirim" aria-labelledby="inv-title">
      <div className="invest__bg" aria-hidden="true">
        <img src={asset('img/facade-grid-bw-1440.webp')} srcSet={`${asset('img/facade-grid-bw-1024.webp')} 1024w, ${asset('img/facade-grid-bw-1440.webp')} 1440w`} sizes="100vw" alt="" loading="lazy" decoding="async" width={1440} height={955} data-parallax-bg />
      </div>
      <div className="container grid">
        <div className="invest__head">
          <div>
            <p className="label" data-reveal>
              <span className="index">05</span> {t.investment.label}
            </p>
            <h2 id="inv-title" className="display display--xl" data-reveal style={{ marginTop: 28 }}>
              <span className="line">{t.investment.headline[0]}</span>
              <span className="line accent">{t.investment.headline[1]}</span>
            </h2>
          </div>
          <div data-reveal>
            <Compass />
          </div>
        </div>
        <p className="body invest__body" data-reveal>
          {t.investment.body}
        </p>
        <ul className="invest__principles">
          {t.investment.principles.map((p, i) => (
            <li className="principle" key={p.title} data-reveal>
              <span className="principle__num">0{i + 1}</span>
              <h3 className="principle__title">{p.title}</h3>
              <p className="principle__text">{p.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
