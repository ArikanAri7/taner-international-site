import { asset } from '../../lib/asset'
import { useEffect, useRef, useState } from 'react'
import { useT } from '../../i18n'
import { lerp } from '../../lib/motion'

const IMAGES: Record<string, string> = {
  'taner-property': 'brick-residential',
  'taner-yapi': 'building-under-construction',
  besutan: 'amsterdam-canal-night',
  topgreen: 'solar-array',
}

function ArrowIcon() {
  return (
    <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M3 13 13 3M5 3h8v8" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  )
}

export function Divisions() {
  const t = useT()
  const listRef = useRef<HTMLDivElement>(null)
  const previewRef = useRef<HTMLDivElement>(null)
  const [activeId, setActiveId] = useState<string | null>(null)

  // Floating preview follows the cursor over the list (desktop only).
  useEffect(() => {
    const list = listRef.current
    const preview = previewRef.current
    if (!list || !preview) return
    if (window.matchMedia('(pointer: coarse)').matches) return
    const target = { x: 0, y: 0 }
    const cur = { x: 0, y: 0 }
    let raf = 0
    let running = false
    const loop = () => {
      cur.x = lerp(cur.x, target.x, 0.14)
      cur.y = lerp(cur.y, target.y, 0.14)
      preview.style.transform = `translate(${cur.x}px, ${cur.y}px) translate(-50%, -50%) scale(${preview.classList.contains('is-on') ? 1 : 0.92})`
      if (Math.abs(cur.x - target.x) > 0.1 || Math.abs(cur.y - target.y) > 0.1 || preview.classList.contains('is-on')) {
        raf = requestAnimationFrame(loop)
      } else running = false
    }
    const onMove = (e: PointerEvent) => {
      const r = list.getBoundingClientRect()
      target.x = e.clientX - r.left
      target.y = e.clientY - r.top
      if (!running) {
        running = true
        raf = requestAnimationFrame(loop)
      }
    }
    list.addEventListener('pointermove', onMove, { passive: true })
    return () => {
      list.removeEventListener('pointermove', onMove)
      cancelAnimationFrame(raf)
    }
  }, [])

  return (
    <section className="section theme-light divisions" id="faaliyet-alanlari" aria-labelledby="div-title">
      <div className="container grid">
        <div className="div__head">
          <p className="label" data-reveal>
            <span className="index">04</span> {t.divisions.label}
          </p>
          <h2 id="div-title" className="display display--l" data-reveal style={{ marginTop: 28, maxWidth: '14ch' }}>
            {t.divisions.headline}
          </h2>
        </div>
        <p className="body div__intro" data-reveal>
          {t.divisions.intro}
        </p>

        <div
          className="div__list"
          ref={listRef}
          onPointerLeave={() => {
            setActiveId(null)
            previewRef.current?.classList.remove('is-on')
          }}
        >
          <div
            className={`div__preview ${activeId === 'opuze' ? 'div__preview--logo' : ''}`}
            ref={previewRef}
            aria-hidden="true"
          >
            {Object.entries(IMAGES).map(([id, img]) => (
              <img
                key={id}
                className={activeId === id ? 'is-on' : ''}
                src={`${asset('')}img/${img}-640.webp`}
                srcSet={`${asset('')}img/${img}-640.webp 640w, ${asset('')}img/${img}-1024.webp 1024w`}
                sizes="300px"
                alt=""
                loading="lazy"
                decoding="async"
              />
            ))}
            {activeId === 'opuze' && <img src={asset('brand/opuze-logo.svg')} alt="" loading="lazy" decoding="async" width={452} height={116} />}
          </div>

          {t.divisions.items.map((d, i) => {
            const Tag = d.url ? 'a' : 'article'
            const common = {
              className: 'division',
              id: d.id,
              'data-reveal': '',
              onPointerEnter: () => {
                setActiveId(d.id)
                previewRef.current?.classList.add('is-on')
              },
            }
            const content = (
              <>
                <div className="division__thumb" aria-hidden="true">
                  {IMAGES[d.id] ? (
                    <img src={`${asset('')}img/${IMAGES[d.id]}-640.webp`} alt="" loading="lazy" decoding="async" width={640} height={427} />
                  ) : (
                    <div className="division__thumb--logo" style={{ height: '100%' }}>
                      <img src={asset('brand/opuze-logo.svg')} alt="" loading="lazy" decoding="async" width={452} height={116} />
                    </div>
                  )}
                </div>
                <span className="index">0{i + 1}</span>
                <h3 className="division__name">{d.name}</h3>
                <div className="division__meta">
                  <span className="division__cat">{d.category}</span>
                  <p className="division__desc">{d.description}</p>
                </div>
                <span className="division__arrow" aria-hidden={!d.url}>
                  {d.url ? <ArrowIcon /> : <span style={{ width: 6, height: 6, background: 'var(--gold)', borderRadius: '50%' }} />}
                </span>
                {d.url && (
                  <span className="sr-only">
                    {t.divisions.visit} — {t.a11y.externalLink}
                  </span>
                )}
              </>
            )
            return Tag === 'a' ? (
              <a key={d.id} {...common} href={d.url} target="_blank" rel="noopener noreferrer">
                {content}
              </a>
            ) : (
              <article key={d.id} {...common}>
                {content}
              </article>
            )
          })}
        </div>
      </div>
    </section>
  )
}
