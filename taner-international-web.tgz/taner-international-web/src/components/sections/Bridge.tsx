import { asset } from '../../lib/asset'
import { useEffect, useRef } from 'react'
import { useT } from '../../i18n'
import { Picture } from '../Picture'
import { gsap, ScrollTrigger, prefersReducedMotion } from '../../lib/motion'

// Same projection as scripts/build-map.mjs (plate carrée, standard parallel 48°)
const LON0 = -30, LON1 = 60, LAT0 = 33, LAT1 = 63
const K = Math.cos((48 * Math.PI) / 180)
const VW = 1000
const VH = Math.round(VW * ((LAT1 - LAT0) / ((LON1 - LON0) * K)))
const project = (lat: number, lon: number) => ({
  x: ((lon - LON0) * K * VW) / ((LON1 - LON0) * K),
  y: ((LAT1 - lat) * VH) / (LAT1 - LAT0),
})
const NL = project(52.37, 4.9)
const IZ = project(38.42, 27.14)
// lifted arc: control point offset perpendicular to the chord
const mx = (NL.x + IZ.x) / 2
const my = (NL.y + IZ.y) / 2
const dx = IZ.x - NL.x
const dy = IZ.y - NL.y
const len = Math.hypot(dx, dy)
const CX = mx + (dy / len) * len * 0.28
const CY = my - (dx / len) * len * 0.28
const ROUTE = `M ${NL.x} ${NL.y} Q ${CX} ${CY} ${IZ.x} ${IZ.y}`

export function Bridge() {
  const t = useT()
  const pathRef = useRef<SVGPathElement>(null)
  const dotRef = useRef<SVGCircleElement>(null)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const path = pathRef.current
    const dot = dotRef.current
    const section = sectionRef.current
    if (!path || !dot || !section) return
    const L = path.getTotalLength()
    path.style.strokeDasharray = `${L}`
    path.style.strokeDashoffset = `${L}`
    const start = path.getPointAtLength(0)
    dot.setAttribute('cx', `${start.x}`)
    dot.setAttribute('cy', `${start.y}`)
    if (prefersReducedMotion()) {
      path.style.strokeDashoffset = '0'
      const p = path.getPointAtLength(L)
      dot.setAttribute('cx', `${p.x}`)
      dot.setAttribute('cy', `${p.y}`)
      return
    }
    const state = { p: 0 }
    const tween = gsap.to(state, {
      p: 1,
      ease: 'none',
      scrollTrigger: { trigger: section.querySelector('.bridge__map'), start: 'top 75%', end: 'bottom 45%', scrub: 0.6 },
      onUpdate: () => {
        path.style.strokeDashoffset = `${L * (1 - state.p)}`
        const p = path.getPointAtLength(L * state.p)
        dot.setAttribute('cx', `${p.x}`)
        dot.setAttribute('cy', `${p.y}`)
      },
    })
    return () => {
      tween.scrollTrigger?.kill()
      tween.kill()
      ScrollTrigger.refresh()
    }
  }, [])

  return (
    <section className="section theme-charcoal bridge" id="hollanda-turkiye" aria-labelledby="bridge-title" ref={sectionRef}>
      <div className="container grid">
        <div className="bridge__head">
          <p className="label" data-reveal>
            <span className="index">03</span> {t.bridge.label}
          </p>
          <h2 id="bridge-title" className="display display--xl" data-reveal style={{ marginTop: 28 }}>
            <span className="line">{t.bridge.headline[0]}</span>
            <span className="line">{t.bridge.headline[1]}</span>
          </h2>
        </div>
        <p className="body bridge__body" data-reveal>
          {t.bridge.body}
        </p>

        <div className="bridge__map" data-reveal>
          <img src={asset('img/europe-dots-1200.png')} srcSet={`${asset('img/europe-dots-1200.png')} 1200w, ${asset('img/europe-dots.png')} 2400w`} sizes="100vw" alt="" width={2400} height={1196} loading="lazy" decoding="async" />
          <svg viewBox={`0 0 ${VW} ${VH}`} preserveAspectRatio="xMidYMid slice" aria-hidden="true">
            <path className="bridge__route bridge__route--ghost" d={ROUTE} />
            <path className="bridge__route" d={ROUTE} ref={pathRef} />
            <circle className="bridge__pulse" cx={NL.x} cy={NL.y} r={6} />
            <circle className="bridge__pulse" cx={IZ.x} cy={IZ.y} r={6} style={{ animationDelay: '1.5s' }} />
            <circle className="bridge__city" cx={NL.x} cy={NL.y} r={3.2} />
            <circle className="bridge__city" cx={IZ.x} cy={IZ.y} r={3.2} />
            <circle ref={dotRef} r={2.6} fill="#f5f3ee" />
          </svg>
          <div className="bridge__tag" style={{ left: `${(NL.x / VW) * 100}%`, top: `calc(${(NL.y / VH) * 100}% - 3.2em)` }}>
            <span>{t.bridge.nl}</span>
            <small>52.4° N · 4.9° E</small>
          </div>
          <div className="bridge__tag" style={{ left: `${(IZ.x / VW) * 100}%`, top: `calc(${(IZ.y / VH) * 100}% + 1em)` }}>
            <span>
              {t.bridge.tr} · {t.bridge.izmir}
            </span>
            <small>38.4° N · 27.1° E</small>
          </div>
        </div>

        <div className="bridge__photos">
          <div>
            <Picture name="amsterdam-canal-day" ratio="4-3" mask parallax sizes="(max-width: 900px) 100vw, 42vw" />
            <p className="caption" data-reveal>
              <span>{t.bridge.captionNl}</span>
              <span>52° N</span>
            </p>
          </div>
          <div aria-hidden="true" />
          <div className="bridge__photo--right">
            <Picture name="izmir-bay-aerial" ratio="4-3" mask parallax sizes="(max-width: 900px) 100vw, 42vw" />
            <p className="caption" data-reveal>
              <span>{t.bridge.captionTr}</span>
              <span>38° N</span>
            </p>
          </div>
        </div>

        <ul className="bridge__points">
          {t.bridge.points.map((p, i) => (
            <li key={p.title} data-reveal>
              <h3 className="point__title">
                <span className="index">0{i + 1}</span>
                {p.title}
              </h3>
              <p className="point__text">{p.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
