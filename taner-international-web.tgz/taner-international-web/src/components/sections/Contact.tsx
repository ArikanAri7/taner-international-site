import { useEffect, useRef } from 'react'
import { useT } from '../../i18n'
import { lerp, prefersReducedMotion } from '../../lib/motion'

export function Contact() {
  const t = useT()
  const ref = useRef<HTMLElement>(null)
  const magnetRef = useRef<HTMLAnchorElement>(null)

  // Cursor-reactive gold glow + magnetic CTA (desktop only).
  useEffect(() => {
    const el = ref.current
    const magnet = magnetRef.current
    if (!el || !magnet) return
    if (prefersReducedMotion() || window.matchMedia('(pointer: coarse)').matches) return
    let raf = 0
    const cur = { x: 0, y: 0 }
    const target = { x: 0, y: 0 }
    const onMove = (e: PointerEvent) => {
      const r = el.getBoundingClientRect()
      el.style.setProperty('--gx', `${((e.clientX - r.left) / r.width) * 100}%`)
      el.style.setProperty('--gy', `${((e.clientY - r.top) / r.height) * 100}%`)
      const m = magnet.getBoundingClientRect()
      const dx = e.clientX - (m.left + m.width / 2)
      const dy = e.clientY - (m.top + m.height / 2)
      const d = Math.hypot(dx, dy)
      const range = 140
      if (d < range) {
        const f = (1 - d / range) * 0.35
        target.x = dx * f
        target.y = dy * f
      } else {
        target.x = 0
        target.y = 0
      }
      if (!raf) raf = requestAnimationFrame(tick)
    }
    const tick = () => {
      cur.x = lerp(cur.x, target.x, 0.18)
      cur.y = lerp(cur.y, target.y, 0.18)
      magnet.style.transform = `translate(${cur.x.toFixed(2)}px, ${cur.y.toFixed(2)}px)`
      raf = Math.abs(cur.x - target.x) + Math.abs(cur.y - target.y) > 0.05 ? requestAnimationFrame(tick) : 0
    }
    const onLeave = () => {
      target.x = 0
      target.y = 0
      if (!raf) raf = requestAnimationFrame(tick)
    }
    el.addEventListener('pointermove', onMove, { passive: true })
    el.addEventListener('pointerleave', onLeave)
    return () => {
      el.removeEventListener('pointermove', onMove)
      el.removeEventListener('pointerleave', onLeave)
      cancelAnimationFrame(raf)
    }
  }, [])

  const subject = encodeURIComponent('TANER INTERNATIONAL')
  return (
    <section className="section theme-dark contact" id="iletisim" aria-labelledby="contact-title" ref={ref}>
      <div className="contact__glow" aria-hidden="true" />
      <div className="container grid">
        <div className="contact__head">
          <p className="label" data-reveal>
            <span className="index">09</span> {t.contact.label}
          </p>
          <h2 id="contact-title" className="display display--xl contact__headline" data-reveal style={{ marginTop: 28 }}>
            <span className="line accent">{t.contact.headline[0]}</span>
            <span className="line">{t.contact.headline[1]}</span>
          </h2>
          <p className="lead" data-reveal style={{ marginTop: 32, maxWidth: '40ch' }}>
            {t.contact.body}
          </p>
          <div data-reveal style={{ marginTop: 40 }}>
            <a className="btn btn--gold magnet" href={`mailto:${t.contact.email}?subject=${subject}`} ref={magnetRef}>
              <span>{t.contact.cta}</span>
              <svg className="arrow" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M3 13 13 3M5 3h8v8" stroke="currentColor" strokeWidth="1.4" />
              </svg>
            </a>
          </div>
        </div>
        <div className="contact__row">
          <div className="contact__item" data-reveal>
            <span className="contact__k">{t.contact.emailLabel}</span>
            <a className="contact__v link-u" href={`mailto:${t.contact.email}`}>
              {t.contact.email}
            </a>
          </div>
          <div className="contact__item" data-reveal>
            <span className="contact__k">{t.contact.locationsLabel}</span>
            <span className="contact__v">{t.contact.locations}</span>
          </div>
          <div className="contact__item" data-reveal>
            <span className="contact__k">{t.contact.divisionsLabel}</span>
            <div className="contact__links">
              {t.divisions.items.map((d) => (
                <a key={d.id} className="link-u" href={`#${d.id}`} style={{ alignSelf: 'flex-start' }}>
                  {d.name}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
