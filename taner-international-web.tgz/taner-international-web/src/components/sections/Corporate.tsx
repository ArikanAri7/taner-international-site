import { useT } from '../../i18n'
import { Picture } from '../Picture'

export function Corporate() {
  const t = useT()
  return (
    <section className="section theme-light corp" id="grup" aria-labelledby="corp-title">
      <div className="container grid">
        <div className="corp__head">
          <p className="label" data-reveal>
            <span className="index">02</span> {t.corporate.label}
          </p>
          <h2 id="corp-title" className="display display--xl" data-reveal style={{ marginTop: 28 }}>
            <span className="line">{t.corporate.headline[0]}</span>
            <span className="line accent">{t.corporate.headline[1]}</span>
          </h2>
        </div>
        <div className="corp__image">
          <Picture name="concrete-curve-light" ratio="4-3" mask parallax sizes="(max-width: 900px) 100vw, 40vw" />
          <p className="caption" data-reveal>
            <span>TANER INTERNATIONAL GROUP</span>
            <span>{t.hero.eyebrow}</span>
          </p>
        </div>
        <div className="corp__text">
          <p className="lead" data-reveal>
            {t.corporate.lead}
          </p>
          <p className="body" data-reveal>
            {t.corporate.body}
          </p>
        </div>
        <ul className="corp__facts" data-reveal>
          {t.corporate.facts.map((f) => (
            <li className="fact" key={f.label}>
              <div className="fact__value mono-num">
                {f.value.replace('+', '')}
                {f.value.endsWith('+') && <sup>+</sup>}
              </div>
              <div className="fact__label">{f.label}</div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
