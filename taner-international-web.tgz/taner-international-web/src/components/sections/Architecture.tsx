import { useT } from '../../i18n'
import { Picture } from '../Picture'

export function Architecture() {
  const t = useT()
  return (
    <section className="section theme-light arch" id="mimari" aria-labelledby="arch-title">
      <div className="container grid">
        <div className="arch__head">
          <p className="label" data-reveal>
            <span className="index">06</span> {t.architecture.label}
          </p>
          <h2 id="arch-title" className="display display--xl" data-reveal style={{ marginTop: 28 }}>
            <span className="line">{t.architecture.headline[0]}</span>
            <span className="line">{t.architecture.headline[1]}</span>
          </h2>
        </div>
        <div className="arch__body">
          <p className="body" data-reveal>
            {t.architecture.body}
          </p>
          <div className="arch__links" data-reveal>
            {t.architecture.links.map((l) => (
              <a key={l.href} className="link-u" href={l.href}>
                {l.label} ↗
              </a>
            ))}
          </div>
        </div>

        <div className="arch__gallery">
          <div className="arch__g1">
            <Picture name="concrete-curve-bw" ratio="3-2" mask parallax sizes="(max-width: 900px) 100vw, 66vw" />
          </div>
          <div className="arch__g2">
            <Picture name="curved-staircase-white" ratio="2-3" mask parallax sizes="(max-width: 900px) 50vw, 30vw" width={1440} height={2159} />
          </div>
          <div className="arch__g3">
            <Picture name="minimal-staircase" ratio="2-3" mask parallax sizes="(max-width: 900px) 50vw, 30vw" width={1440} height={2160} />
          </div>
          <div className="arch__g4">
            <Picture name="spiral-stairs-bw" ratio="4-3" mask parallax sizes="(max-width: 900px) 100vw, 50vw" />
          </div>
        </div>
        <p className="arch__note" data-reveal>
          {t.architecture.note}
        </p>
      </div>
    </section>
  )
}
