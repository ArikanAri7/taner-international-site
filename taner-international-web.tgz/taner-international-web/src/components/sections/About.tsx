import { useT } from '../../i18n'
import { Picture } from '../Picture'

export function About() {
  const t = useT()
  return (
    <section className="section theme-light about" id="hakkimizda" aria-labelledby="about-title">
      <div className="container grid">
        <div className="about__head">
          <div>
            <p className="label" data-reveal>
              <span className="index">08</span> {t.about.label}
            </p>
            <h2 id="about-title" className="display display--xl" data-reveal style={{ marginTop: 28 }}>
              <span className="line">{t.about.headline[0]}</span>
              <span className="line">{t.about.headline[1]}</span>
            </h2>
          </div>
          <div className="about__stat" data-reveal>
            <div className="about__stat-value mono-num" aria-label={`${t.about.stat.value} ${t.about.stat.label}`}>
              40<span>+</span>
            </div>
            <div className="about__stat-label">{t.about.stat.label}</div>
          </div>
        </div>
        <div className="about__image">
          <Picture name="brutalist-bw" ratio="4-3" mask parallax mono sizes="(max-width: 900px) 100vw, 50vw" />
        </div>
        <div className="about__text">
          <p className="lead" data-reveal>
            {t.about.p1}
          </p>
          <p className="body" data-reveal>
            {t.about.p2}
          </p>
        </div>
        <ul className="about__pillars">
          {t.about.pillars.map((p) => (
            <li className="pillar" key={p.title} data-reveal>
              <h3 className="pillar__title">{p.title}</h3>
              <p className="pillar__text">{p.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
