import { useT } from '../../i18n'
import { Picture } from '../Picture'

export function Energy() {
  const t = useT()
  return (
    <section className="section theme-charcoal energy" id="enerji" aria-labelledby="energy-title">
      <div className="container grid">
        <div className="energy__main">
          <Picture name="solar-aerial-parking" ratio="21-9" mask parallax sizes="100vw" width={1440} height={896} />
          <p className="caption" data-reveal>
            <span>TOPGREEN SOLUTIONS</span>
            <span>{t.energy.note}</span>
          </p>
        </div>
        <div className="energy__text">
          <p className="label" data-reveal>
            <span className="index">07</span> {t.energy.label}
          </p>
          <h2 id="energy-title" className="display display--l" data-reveal>
            <span className="line">{t.energy.headline[0]}</span>
            <span className="line accent">{t.energy.headline[1]}</span>
          </h2>
          <p className="body" data-reveal>
            {t.energy.body}
          </p>
          <ul className="energy__bullets" data-reveal>
            {t.energy.bullets.map((b, i) => (
              <li key={b}>
                <span>{b}</span>
                <span className="index">0{i + 1}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="energy__side">
          <Picture name="solar-building-aerial" ratio="4-3" mask parallax sizes="(max-width: 900px) 100vw, 50vw" />
          <Picture name="solar-array" ratio="16-9" mask parallax sizes="(max-width: 900px) 100vw, 50vw" />
        </div>
      </div>
    </section>
  )
}
