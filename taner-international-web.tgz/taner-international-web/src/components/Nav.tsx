import { asset } from '../lib/asset'
import { useEffect, useRef, useState } from 'react'
import { useI18n, LANGS } from '../i18n'
import type { Lang } from '../i18n/types'

export function LanguageSwitch({ className = '' }: { className?: string }) {
  const { lang, setLang, t } = useI18n()
  return (
    <div className={`lang ${className}`} role="group" aria-label={t.nav.language}>
      {LANGS.map((l, i) => (
        <span key={l} style={{ display: 'contents' }}>
          {i > 0 && (
            <span className="lang__sep" aria-hidden="true">
              /
            </span>
          )}
          <button
            type="button"
            className="lang__btn"
            aria-pressed={lang === l}
            lang={l}
            onClick={() => setLang(l as Lang)}
          >
            {l.toUpperCase()}
          </button>
        </span>
      ))}
    </div>
  )
}

export function Nav() {
  const { t } = useI18n()
  const [open, setOpen] = useState(false)
  const [hidden, setHidden] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const lastY = useRef(0)

  const links = [
    { href: '#grup', label: t.nav.group },
    { href: '#faaliyet-alanlari', label: t.nav.divisions },
    { href: '#yatirim', label: t.nav.investment },
    { href: '#hakkimizda', label: t.nav.about },
    { href: '#iletisim', label: t.nav.contact },
  ]

  useEffect(() => {
    let ticking = false
    const onScroll = () => {
      if (ticking) return
      ticking = true
      requestAnimationFrame(() => {
        const y = window.scrollY
        setScrolled(y > 40)
        setHidden(y > 160 && y > lastY.current && !open)
        lastY.current = y
        ticking = false
      })
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [open])

  useEffect(() => {
    document.documentElement.style.overflow = open ? 'hidden' : ''
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  return (
    <>
      <a className="skip-link" href="#main">
        {t.nav.skip}
      </a>
      <header className={`nav ${hidden ? 'is-hidden' : ''} ${scrolled ? 'is-scrolled' : ''}`}>
        <a className="nav__logo" href="#top" aria-label="TANER INTERNATIONAL">
          <img src={asset("brand/taner-international-logo.png")} alt="" width={711} height={182} />
        </a>
        <nav className="nav__links" aria-label="Primary">
          {links.map((l) => (
            <a key={l.href} className="link-u" href={l.href}>
              {l.label}
            </a>
          ))}
        </nav>
        <div className="nav__right">
          <LanguageSwitch />
          <button
            type="button"
            className="nav__burger"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? t.nav.close : t.nav.menu}
            onClick={() => setOpen((v) => !v)}
          >
            <span />
            <span />
          </button>
        </div>
      </header>

      <div id="mobile-menu" className={`menu ${open ? 'is-open' : ''}`} aria-hidden={!open}>
        <nav className="menu__links" aria-label="Mobile">
          {links.map((l, i) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)} tabIndex={open ? 0 : -1}>
              <span className="index">0{i + 1}</span>
              {l.label}
            </a>
          ))}
        </nav>
        <div className="menu__bottom">
          <span>{t.hero.eyebrow}</span>
          <LanguageSwitch />
        </div>
      </div>
    </>
  )
}
