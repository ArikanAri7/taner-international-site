import { asset } from '../lib/asset'
import { useT } from '../i18n'
import { LanguageSwitch } from './Nav'

export function Footer() {
  const t = useT()
  const year = new Date().getFullYear()
  return (
    <footer className="footer theme-dark" role="contentinfo">
      <div className="container">
        <div className="footer__top">
          <div className="footer__brand">
            <a href="#top" aria-label={t.a11y.toTop}>
              <img src={asset("brand/taner-international-logo.png")} alt="TANER INTERNATIONAL" width={711} height={182} loading="lazy" />
            </a>
            <p>{t.footer.tagline}</p>
          </div>
          <div className="footer__col">
            <h4>{t.footer.divisions}</h4>
            <ul>
              {t.divisions.items.map((d) => (
                <li key={d.id}>
                  {d.url ? (
                    <a href={d.url} target="_blank" rel="noopener noreferrer">
                      {d.name} ↗<span className="sr-only"> ({t.a11y.externalLink})</span>
                    </a>
                  ) : (
                    <a href={`#${d.id}`}>{d.name}</a>
                  )}
                </li>
              ))}
            </ul>
          </div>
          <div className="footer__col">
            <h4>{t.footer.contact}</h4>
            <ul>
              <li>
                <a href={`mailto:${t.contact.email}`}>{t.contact.email}</a>
              </li>
              <li>{t.contact.locations}</li>
            </ul>
          </div>
          <div className="footer__col">
            <h4>{t.footer.language}</h4>
            <LanguageSwitch />
          </div>
        </div>
        <div className="footer__bottom">
          <span>
            © {year} Taner International Group. {t.footer.rights}
          </span>
          <span>{t.footer.illustrative}</span>
          <span>
            {t.footer.partner}:{' '}
            <a href="https://opuze.com/" target="_blank" rel="noopener noreferrer">
              Opuze
            </a>
          </span>
        </div>
      </div>
    </footer>
  )
}
