import type { Dictionary } from './types'

export const tr: Dictionary = {
  meta: {
    title: 'TANER INTERNATIONAL — Türkiye ve Hollanda arasında yatırım, gayrimenkul ve enerji',
    description:
      '40 yılı aşkın geçmişe sahip köklü bir aile holdingi. Taner Property, Taner Yapı İnşaat, Besutan Limited, TopGreen Solutions ve Opuze ile Türkiye ve Hollanda arasında gayrimenkul, inşaat, yenilenebilir enerji ve yaratıcı hizmetler.',
    ogTitle: 'TANER INTERNATIONAL — Güçlü Bir Geçmiş. Uluslararası Bir Vizyon.',
  },
  nav: {
    group: 'Grup',
    divisions: 'Faaliyet Alanları',
    investment: 'Yatırım',
    about: 'Hakkımızda',
    contact: 'İletişim',
    menu: 'Menü',
    close: 'Kapat',
    language: 'Dil',
    skip: 'İçeriğe geç',
  },
  hero: {
    eyebrow: 'Türkiye · Hollanda',
    statement:
      'Uluslararası ticarette, yatırımda ve geleceği şekillendiren projelerde değer yaratıyoruz. 40 yılı aşkın geçmişe sahip köklü bir aile holdingi.',
    cta: 'İletişime geçin',
    scroll: 'Keşfet',
    routeFrom: 'Hollanda',
    routeTo: 'Türkiye · İzmir',
    sceneAlt: 'Türkiye ile Hollanda arasındaki bağlantıyı gösteren üç boyutlu dünya sahnesi',
  },
  corporate: {
    label: 'Kurumsal',
    headline: ['Güçlü Bir Geçmiş.', 'Uluslararası Bir Vizyon.'],
    lead: 'Taner International Group, 40 yılı aşkın geçmişe sahip köklü bir aile şirketidir.',
    body:
      'Uluslararası düşünen, güvenilir ve profesyonel yapısıyla Türkiye’de güçlü yatırım fırsatları sunar. Gayrimenkulden enerjiye, inşaattan yaratıcı ajansa uzanan entegre bir holding yapısıyla uzun vadeli değer yaratır.',
    facts: [
      { value: '40+', label: 'yıllık aile geçmişi' },
      { value: '5', label: 'faaliyet alanı' },
      { value: '2', label: 'pazar: Türkiye · Hollanda' },
    ],
  },
  bridge: {
    label: 'Türkiye ve Hollanda Arasında',
    headline: ['İki Pazar.', 'Ortak Bir Vizyon.'],
    body:
      'Besutan Limited, Türkiye ile Hollanda arasında yatırım, gayrimenkul, renovasyon, kiralama ve ticari bağlantılar kuran uluslararası köprümüzdür. İki pazarı tanıyan, iki dilde düşünen bir yapı.',
    nl: 'Hollanda',
    tr: 'Türkiye',
    izmir: 'İzmir',
    captionNl: 'Hollanda — kanal evleri, Amsterdam',
    captionTr: 'Türkiye — İzmir Körfezi',
    points: [
      { title: 'Yatırım', text: 'İki ülke arasında güvenilir yatırım bağlantıları.' },
      { title: 'Gayrimenkul', text: 'Alım, geliştirme ve kiralama süreçlerinde yerel bilgi.' },
      { title: 'Renovasyon', text: 'Mevcut yapıların yenilenmesi ve değer kazandırılması.' },
      { title: 'Ticari bağlantılar', text: 'Türkiye ve Hollanda pazarları arasında iş ilişkileri.' },
    ],
  },
  divisions: {
    label: 'Faaliyet Alanları',
    headline: 'Gayrimenkulden enerjiye, inşaattan yaratıcı ajansa.',
    intro:
      'Beş marka, tek bir holding yapısı. Her biri kendi alanında uzmanlaşmış; hepsi aynı uzun vadeli bakışı paylaşıyor.',
    visit: 'Web sitesini ziyaret et',
    items: [
      {
        id: 'taner-property',
        name: 'Taner Property',
        category: 'Gayrimenkul · İzmir',
        description:
          'Gayrimenkul, proje geliştirme, inşaat, sanal ofis ve yatırımı tek çatı altında birleştirerek uzun vadeli değer yaratır.',
      },
      {
        id: 'taner-yapi',
        name: 'Taner Yapı İnşaat',
        category: 'İnşaat',
        description:
          'Modern yaşam alanları ve ticari yapılar inşa ederek estetik, kalite ve güveni bir araya getirir.',
      },
      {
        id: 'besutan',
        name: 'Besutan Limited',
        category: 'Türkiye · Hollanda',
        description:
          'Türkiye ile Hollanda arasında yatırım, gayrimenkul, renovasyon, kiralama ve ticari bağlantılar kuran uluslararası köprü.',
      },
      {
        id: 'topgreen',
        name: 'TopGreen Solutions',
        category: 'Yenilenebilir Enerji',
        description:
          'Güneş enerjisi sistemleri, enerji depolama bataryaları ve yenilenebilir enerji çözümleriyle çevre dostu, verimli teknolojiler sunar.',
      },
      {
        id: 'opuze',
        name: 'Opuze',
        category: 'Yaratıcı Ajans',
        description:
          'Marka, dijital ve yaratıcı üretim alanında faaliyet gösteren ajans. Taner International Group’un iletişim ve medya partneri.',
        url: 'https://opuze.com/',
      },
    ],
  },
  investment: {
    label: 'Yatırım ve Değer Yaratma',
    headline: ['Sınırların', 'Ötesinde Değer.'],
    body:
      'Yatırım anlayışımız kısa vadeli dalgalanmalara değil, kalıcı değere odaklanır. Gayrimenkul, inşaat ve enerjiyi aynı çatı altında toplayan yapımız, her projeye bütüncül bakmamızı sağlar.',
    principles: [
      {
        title: 'Uzun vadeli yaklaşım',
        text: 'Projeleri yıllarla değil, nesillerle ölçeriz. Aile şirketi olmanın getirdiği sabır ve süreklilik.',
      },
      {
        title: 'Entegre yapı',
        text: 'Gayrimenkul, inşaat, enerji ve iletişim tek bir holding bünyesinde; kararlar tek elden, uygulama bütünleşik.',
      },
      {
        title: 'Uluslararası bakış',
        text: 'Türkiye’deki fırsatları Hollanda’daki deneyimle birleştiren, iki pazarı da tanıyan bir perspektif.',
      },
    ],
  },
  architecture: {
    label: 'Mimari ve Gayrimenkul',
    headline: ['Yaşam alanları.', 'Ticari yapılar.'],
    body:
      'Taner Property ve Taner Yapı İnşaat; gayrimenkul geliştirmeden inşaata, sanal ofisten yatırıma uzanan bir yelpazede modern yaşam alanları ve ticari yapılar üretir. Estetik, kalite ve güven aynı çizgide.',
    links: [
      { label: 'Taner Property', href: '#taner-property' },
      { label: 'Taner Yapı İnşaat', href: '#taner-yapi' },
    ],
    note: 'Görseller temsilidir; belirli bir şirket projesini göstermez.',
  },
  energy: {
    label: 'Enerji ve Sürdürülebilirlik',
    headline: ['Güneşten gelen', 'kalıcı değer.'],
    body:
      'TopGreen Solutions; güneş enerjisi sistemleri, enerji depolama bataryaları ve yenilenebilir enerji çözümleriyle çevre dostu, verimli teknolojiler sunar.',
    bullets: ['Güneş enerjisi sistemleri', 'Enerji depolama bataryaları', 'Yenilenebilir enerji çözümleri'],
    note: 'Görseller temsilidir.',
  },
  about: {
    label: 'Hakkımızda',
    headline: ['Köklü bir aile.', 'Entegre bir yapı.'],
    p1: 'Taner International Group, 40 yılı aşkın geçmişe sahip köklü bir aile şirketidir. Uluslararası düşünen, güvenilir ve profesyonel yapısıyla Türkiye’de güçlü yatırım fırsatları sunar.',
    p2: 'Taner Property, Taner Yapı İnşaat, Besutan, TopGreen Solutions ve Opuze markalarıyla gayrimenkulden enerjiye, inşaattan yaratıcı ajansa uzanan entegre bir holding yapısı oluşturur.',
    stat: { value: '40+', label: 'yılı aşkın aile geçmişi' },
    pillars: [
      { title: 'Aile şirketi', text: 'Kararlarda süreklilik, ilişkilerde güven.' },
      { title: 'Çok disiplinli', text: 'Gayrimenkul, inşaat, enerji ve yaratıcı hizmetler.' },
      { title: 'Uluslararası', text: 'Türkiye ve Hollanda pazarlarında faaliyet.' },
    ],
  },
  contact: {
    label: 'İletişim ve İş Birliği',
    headline: ['Geleceği', 'Birlikte İnşa Edelim.'],
    body: 'Yatırım fırsatları ve iş birlikleri için bizimle iletişime geçin.',
    emailLabel: 'E-posta',
    email: 'info@tannerinternational.com',
    locations: 'Türkiye · Hollanda',
    locationsLabel: 'Faaliyet bölgeleri',
    cta: 'E-posta gönderin',
    divisionsLabel: 'Faaliyet alanları',
  },
  footer: {
    tagline: 'Türkiye ve Hollanda arasında yatırım, gayrimenkul, inşaat ve enerji.',
    divisions: 'Markalar',
    contact: 'İletişim',
    language: 'Dil',
    rights: 'Tüm hakları saklıdır.',
    partner: 'Creative partner',
    illustrative: 'Fotoğraflar temsilidir (Unsplash).',
  },
  a11y: {
    externalLink: 'yeni sekmede açılır',
    heroCanvas: 'Dekoratif üç boyutlu sahne',
    toTop: 'Başa dön',
    imgAlts: {
      'concrete-curve-light': 'Açık renkli beton bir cephenin kavisli detayı',
      'amsterdam-canal-day': 'Amsterdam’da kanal kıyısındaki tarihi binalar',
      'izmir-bay-aerial': 'İzmir Körfezi ve sahil şeridinin havadan görünümü',
      'izmir-clock-tower': 'İzmir Saat Kulesi ve Konak Meydanı',
      'brick-residential': 'Modern tuğla cepheli konut binası',
      'building-under-construction': 'İnşaat hâlindeki çok katlı bir yapı',
      'amsterdam-canal-night': 'Amsterdam’da gece kanal evleri',
      'solar-array': 'Çatı üzerindeki güneş paneli dizisi',
      'solar-aerial-parking': 'Güneş panelleriyle kaplı bir alanın havadan görünümü',
      'solar-building-aerial': 'Çatısı güneş panelleriyle kaplı bir bina',
      'concrete-curve-bw': 'Kavisli beton mimari, siyah-beyaz',
      'spiral-stairs-bw': 'Spiral beton merdiven, siyah-beyaz',
      'curved-staircase-white': 'Beyaz kavisli merdiven',
      'minimal-staircase': 'Minimal beyaz beton merdiven',
      'facade-grid-bw': 'Beton cephe ızgarası, siyah-beyaz',
      'brutalist-bw': 'Brütalist beton cephe detayı',
      'arches-hallway': 'Kemerli uzun bir koridor',
      'rebar-detail': 'İnşaat demiri detayı',
      'texture-concrete-steps': 'Beton basamak dokusu',
      'black-concrete-building': 'Koyu renkli beton bina',
    },
  },
  status: {
    loading3d: 'Üç boyutlu sahne yükleniyor',
    noWebgl: 'Tarayıcınız üç boyutlu sahneyi desteklemiyor; statik görünüm gösteriliyor.',
  },
}
