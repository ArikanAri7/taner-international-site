import type { Dictionary } from './types'

export const en: Dictionary = {
  meta: {
    title: 'TANER INTERNATIONAL — Investment, real estate and energy between Türkiye and the Netherlands',
    description:
      'A family-owned holding with more than 40 years of history. Real estate, construction, renewable energy and creative services between Türkiye and the Netherlands through Taner Property, Taner Yapı İnşaat, Besutan Limited, TopGreen Solutions and Opuze.',
    ogTitle: 'TANER INTERNATIONAL — A Strong Past. An International Vision.',
  },
  nav: {
    group: 'Group',
    divisions: 'Businesses',
    investment: 'Investment',
    about: 'About',
    contact: 'Contact',
    menu: 'Menu',
    close: 'Close',
    language: 'Language',
    skip: 'Skip to content',
  },
  hero: {
    eyebrow: 'Türkiye · Netherlands',
    statement:
      'We create value in international trade, in investment and in the projects that shape the future. A family-owned holding with more than 40 years of history.',
    cta: 'Get in touch',
    scroll: 'Explore',
    routeFrom: 'Netherlands',
    routeTo: 'Türkiye · İzmir',
    sceneAlt: 'Three-dimensional globe scene showing the connection between Türkiye and the Netherlands',
  },
  corporate: {
    label: 'The Group',
    headline: ['A Strong Past.', 'An International Vision.'],
    lead: 'Taner International Group is a family-owned company with more than 40 years of history.',
    body:
      'With an international outlook and a reliable, professional structure, it offers strong investment opportunities in Türkiye. An integrated holding spanning real estate, construction, energy and a creative agency, built to create long-term value.',
    facts: [
      { value: '40+', label: 'years of family history' },
      { value: '5', label: 'areas of activity' },
      { value: '2', label: 'markets: Türkiye · Netherlands' },
    ],
  },
  bridge: {
    label: 'Between Türkiye and the Netherlands',
    headline: ['Two Markets.', 'One Shared Vision.'],
    body:
      'Besutan Limited is our international bridge between Türkiye and the Netherlands — investment, real estate, renovation, leasing and commercial connections. A structure that knows both markets and thinks in both languages.',
    nl: 'Netherlands',
    tr: 'Türkiye',
    izmir: 'İzmir',
    captionNl: 'Netherlands — canal houses, Amsterdam',
    captionTr: 'Türkiye — the Bay of İzmir',
    points: [
      { title: 'Investment', text: 'Reliable investment connections between the two countries.' },
      { title: 'Real estate', text: 'Local knowledge in acquisition, development and leasing.' },
      { title: 'Renovation', text: 'Renewing existing buildings and adding value.' },
      { title: 'Commercial ties', text: 'Business relationships between the Turkish and Dutch markets.' },
    ],
  },
  divisions: {
    label: 'Businesses',
    headline: 'From real estate to energy, from construction to a creative agency.',
    intro:
      'Five brands, one holding structure. Each specialised in its own field; all sharing the same long-term outlook.',
    visit: 'Visit website',
    items: [
      {
        id: 'taner-property',
        name: 'Taner Property',
        category: 'Real Estate · İzmir',
        description:
          'Brings real estate, project development, construction, virtual offices and investment together under one roof to create long-term value.',
      },
      {
        id: 'taner-yapi',
        name: 'Taner Yapı İnşaat',
        category: 'Construction',
        description:
          'Builds modern residential spaces and commercial buildings, bringing together aesthetics, quality and trust.',
      },
      {
        id: 'besutan',
        name: 'Besutan Limited',
        category: 'Türkiye · Netherlands',
        description:
          'An international bridge establishing investment, real estate, renovation, leasing and commercial connections between Türkiye and the Netherlands.',
      },
      {
        id: 'topgreen',
        name: 'TopGreen Solutions',
        category: 'Renewable Energy',
        description:
          'Offers environmentally friendly, efficient technologies through solar energy systems, energy storage batteries and renewable energy solutions.',
      },
      {
        id: 'opuze',
        name: 'Opuze',
        category: 'Creative Agency',
        description:
          'An agency working in brand, digital and creative production. The communication and media partner of Taner International Group.',
        url: 'https://opuze.com/',
      },
    ],
  },
  investment: {
    label: 'Investment and Value Creation',
    headline: ['Value', 'Beyond Borders.'],
    body:
      'Our approach to investment focuses on lasting value rather than short-term movements. Holding real estate, construction and energy under one roof lets us look at every project as a whole.',
    principles: [
      {
        title: 'Long-term approach',
        text: 'We measure projects in generations, not years. The patience and continuity of a family business.',
      },
      {
        title: 'Integrated structure',
        text: 'Real estate, construction, energy and communication within one holding; decisions in one place, execution joined up.',
      },
      {
        title: 'International outlook',
        text: 'A perspective that combines opportunities in Türkiye with experience in the Netherlands, and knows both markets.',
      },
    ],
  },
  architecture: {
    label: 'Architecture and Real Estate',
    headline: ['Living spaces.', 'Commercial buildings.'],
    body:
      'Taner Property and Taner Yapı İnşaat produce modern living spaces and commercial buildings across a range that runs from real estate development to construction, from virtual offices to investment. Aesthetics, quality and trust on one line.',
    links: [
      { label: 'Taner Property', href: '#taner-property' },
      { label: 'Taner Yapı İnşaat', href: '#taner-yapi' },
    ],
    note: 'Images are illustrative and do not show a specific company project.',
  },
  energy: {
    label: 'Energy and Sustainability',
    headline: ['Lasting value', 'from the sun.'],
    body:
      'TopGreen Solutions offers environmentally friendly, efficient technologies through solar energy systems, energy storage batteries and renewable energy solutions.',
    bullets: ['Solar energy systems', 'Energy storage batteries', 'Renewable energy solutions'],
    note: 'Images are illustrative.',
  },
  about: {
    label: 'About',
    headline: ['A rooted family.', 'An integrated structure.'],
    p1: 'Taner International Group is a family-owned company with more than 40 years of history. With an international outlook and a reliable, professional structure, it offers strong investment opportunities in Türkiye.',
    p2: 'Through the Taner Property, Taner Yapı İnşaat, Besutan, TopGreen Solutions and Opuze brands, it forms an integrated holding structure spanning real estate, energy, construction and a creative agency.',
    stat: { value: '40+', label: 'years of family history' },
    pillars: [
      { title: 'Family business', text: 'Continuity in decisions, trust in relationships.' },
      { title: 'Multidisciplinary', text: 'Real estate, construction, energy and creative services.' },
      { title: 'International', text: 'Active in the Turkish and Dutch markets.' },
    ],
  },
  contact: {
    label: 'Contact and Partnership',
    headline: ['Let’s Build', 'the Future Together.'],
    body: 'Get in touch with us about investment opportunities and partnerships.',
    emailLabel: 'Email',
    email: 'info@tannerinternational.com',
    locations: 'Türkiye · Netherlands',
    locationsLabel: 'Regions',
    cta: 'Send an email',
    divisionsLabel: 'Businesses',
  },
  footer: {
    tagline: 'Investment, real estate, construction and energy between Türkiye and the Netherlands.',
    divisions: 'Brands',
    contact: 'Contact',
    language: 'Language',
    rights: 'All rights reserved.',
    partner: 'Creative partner',
    illustrative: 'Photography is illustrative (Unsplash).',
  },
  a11y: {
    externalLink: 'opens in a new tab',
    heroCanvas: 'Decorative three-dimensional scene',
    toTop: 'Back to top',
    imgAlts: {
      'concrete-curve-light': 'Curved detail of a light concrete façade',
      'amsterdam-canal-day': 'Historic canal houses in Amsterdam',
      'izmir-bay-aerial': 'Aerial view of the Bay of İzmir and its waterfront',
      'izmir-clock-tower': 'İzmir Clock Tower and Konak Square',
      'brick-residential': 'Modern brick-clad residential building',
      'building-under-construction': 'A multi-storey building under construction',
      'amsterdam-canal-night': 'Amsterdam canal houses at night',
      'solar-array': 'Rooftop solar panel array',
      'solar-aerial-parking': 'Aerial view of an area covered with solar panels',
      'solar-building-aerial': 'A building with a roof covered in solar panels',
      'concrete-curve-bw': 'Curved concrete architecture, black and white',
      'spiral-stairs-bw': 'Spiral concrete staircase, black and white',
      'curved-staircase-white': 'White curved staircase',
      'minimal-staircase': 'Minimal white concrete staircase',
      'facade-grid-bw': 'Concrete façade grid, black and white',
      'brutalist-bw': 'Brutalist concrete façade detail',
      'arches-hallway': 'A long arched hallway',
      'rebar-detail': 'Reinforcing steel detail on a construction site',
      'texture-concrete-steps': 'Texture of concrete steps',
      'black-concrete-building': 'Dark concrete building',
    },
  },
  status: {
    loading3d: 'Loading the three-dimensional scene',
    noWebgl: 'Your browser does not support the 3D scene; a static view is shown instead.',
  },
}
