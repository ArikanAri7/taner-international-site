export type Lang = 'tr' | 'en' | 'nl'

export interface Division {
  id: string
  name: string
  category: string
  description: string
  url?: string
}

export interface Dictionary {
  meta: { title: string; description: string; ogTitle: string }
  nav: {
    group: string
    divisions: string
    investment: string
    about: string
    contact: string
    menu: string
    close: string
    language: string
    skip: string
  }
  hero: {
    eyebrow: string
    statement: string
    cta: string
    scroll: string
    routeFrom: string
    routeTo: string
    sceneAlt: string
  }
  corporate: {
    label: string
    headline: [string, string]
    lead: string
    body: string
    facts: { value: string; label: string }[]
  }
  bridge: {
    label: string
    headline: [string, string]
    body: string
    nl: string
    tr: string
    izmir: string
    captionNl: string
    captionTr: string
    points: { title: string; text: string }[]
  }
  divisions: {
    label: string
    headline: string
    intro: string
    visit: string
    items: Division[]
  }
  investment: {
    label: string
    headline: [string, string]
    body: string
    principles: { title: string; text: string }[]
  }
  architecture: {
    label: string
    headline: [string, string]
    body: string
    links: { label: string; href: string }[]
    note: string
  }
  energy: {
    label: string
    headline: [string, string]
    body: string
    bullets: string[]
    note: string
  }
  about: {
    label: string
    headline: [string, string]
    p1: string
    p2: string
    stat: { value: string; label: string }
    pillars: { title: string; text: string }[]
  }
  contact: {
    label: string
    headline: [string, string]
    body: string
    emailLabel: string
    email: string
    locations: string
    locationsLabel: string
    cta: string
    divisionsLabel: string
  }
  footer: {
    tagline: string
    divisions: string
    contact: string
    language: string
    rights: string
    partner: string
    illustrative: string
  }
  a11y: {
    externalLink: string
    heroCanvas: string
    toTop: string
    imgAlts: Record<string, string>
  }
  status: {
    loading3d: string
    noWebgl: string
  }
}
