import type { Dictionary } from './types'

export const nl: Dictionary = {
  meta: {
    title: 'TANER INTERNATIONAL — Investeringen, vastgoed en energie tussen Turkije en Nederland',
    description:
      'Een familieholding met meer dan 40 jaar geschiedenis. Vastgoed, bouw, hernieuwbare energie en creatieve diensten tussen Turkije en Nederland via Taner Property, Taner Yapı İnşaat, Besutan Limited, TopGreen Solutions en Opuze.',
    ogTitle: 'TANER INTERNATIONAL — Een sterk verleden. Een internationale visie.',
  },
  nav: {
    group: 'Groep',
    divisions: 'Activiteiten',
    investment: 'Investeren',
    about: 'Over ons',
    contact: 'Contact',
    menu: 'Menu',
    close: 'Sluiten',
    language: 'Taal',
    skip: 'Naar de inhoud',
  },
  hero: {
    eyebrow: 'Turkije · Nederland',
    statement:
      'Wij creëren waarde in internationale handel, in investeringen en in projecten die de toekomst vormgeven. Een familieholding met meer dan 40 jaar geschiedenis.',
    cta: 'Neem contact op',
    scroll: 'Ontdek',
    routeFrom: 'Nederland',
    routeTo: 'Turkije · İzmir',
    sceneAlt: 'Driedimensionale wereldbolscène die de verbinding tussen Turkije en Nederland toont',
  },
  corporate: {
    label: 'De groep',
    headline: ['Een sterk verleden.', 'Een internationale visie.'],
    lead: 'Taner International Group is een familiebedrijf met meer dan 40 jaar geschiedenis.',
    body:
      'Met een internationale blik en een betrouwbare, professionele structuur biedt de groep sterke investeringsmogelijkheden in Turkije. Een geïntegreerde holding van vastgoed en bouw tot energie en een creatief bureau, gebouwd om langdurige waarde te creëren.',
    facts: [
      { value: '40+', label: 'jaar familiegeschiedenis' },
      { value: '5', label: 'activiteiten' },
      { value: '2', label: 'markten: Turkije · Nederland' },
    ],
  },
  bridge: {
    label: 'Tussen Turkije en Nederland',
    headline: ['Twee markten.', 'Eén gedeelde visie.'],
    body:
      'Besutan Limited is onze internationale brug tussen Turkije en Nederland — investeringen, vastgoed, renovatie, verhuur en commerciële verbindingen. Een organisatie die beide markten kent en in beide talen denkt.',
    nl: 'Nederland',
    tr: 'Turkije',
    izmir: 'İzmir',
    captionNl: 'Nederland — grachtenpanden, Amsterdam',
    captionTr: 'Turkije — de baai van İzmir',
    points: [
      { title: 'Investeringen', text: 'Betrouwbare investeringsverbindingen tussen de twee landen.' },
      { title: 'Vastgoed', text: 'Lokale kennis bij aankoop, ontwikkeling en verhuur.' },
      { title: 'Renovatie', text: 'Bestaande gebouwen vernieuwen en waarde toevoegen.' },
      { title: 'Commerciële relaties', text: 'Zakelijke relaties tussen de Turkse en de Nederlandse markt.' },
    ],
  },
  divisions: {
    label: 'Activiteiten',
    headline: 'Van vastgoed tot energie, van bouw tot creatief bureau.',
    intro:
      'Vijf merken, één holdingstructuur. Elk gespecialiseerd in zijn eigen vakgebied; allemaal met dezelfde langetermijnvisie.',
    visit: 'Bezoek website',
    items: [
      {
        id: 'taner-property',
        name: 'Taner Property',
        category: 'Vastgoed · İzmir',
        description:
          'Brengt vastgoed, projectontwikkeling, bouw, virtuele kantoren en investeringen onder één dak samen om langdurige waarde te creëren.',
      },
      {
        id: 'taner-yapi',
        name: 'Taner Yapı İnşaat',
        category: 'Bouw',
        description:
          'Bouwt moderne woonruimten en commerciële gebouwen en verenigt daarbij esthetiek, kwaliteit en vertrouwen.',
      },
      {
        id: 'besutan',
        name: 'Besutan Limited',
        category: 'Turkije · Nederland',
        description:
          'Een internationale brug die investeringen, vastgoed, renovatie, verhuur en commerciële verbindingen tussen Turkije en Nederland tot stand brengt.',
      },
      {
        id: 'topgreen',
        name: 'TopGreen Solutions',
        category: 'Hernieuwbare energie',
        description:
          'Biedt milieuvriendelijke, efficiënte technologieën met zonne-energiesystemen, energieopslagbatterijen en oplossingen voor hernieuwbare energie.',
      },
      {
        id: 'opuze',
        name: 'Opuze',
        category: 'Creatief bureau',
        description:
          'Een bureau actief in merk, digitaal en creatieve productie. De communicatie- en mediapartner van Taner International Group.',
        url: 'https://opuze.com/',
      },
    ],
  },
  investment: {
    label: 'Investeren en waardecreatie',
    headline: ['Waarde', 'over grenzen heen.'],
    body:
      'Onze investeringsaanpak richt zich op blijvende waarde, niet op kortetermijnbewegingen. Doordat vastgoed, bouw en energie onder één dak vallen, bekijken we elk project als geheel.',
    principles: [
      {
        title: 'Langetermijnaanpak',
        text: 'Wij meten projecten in generaties, niet in jaren. Het geduld en de continuïteit van een familiebedrijf.',
      },
      {
        title: 'Geïntegreerde structuur',
        text: 'Vastgoed, bouw, energie en communicatie binnen één holding; besluiten op één plek, uitvoering in samenhang.',
      },
      {
        title: 'Internationale blik',
        text: 'Een perspectief dat kansen in Turkije combineert met ervaring in Nederland en beide markten kent.',
      },
    ],
  },
  architecture: {
    label: 'Architectuur en vastgoed',
    headline: ['Woonruimten.', 'Commerciële gebouwen.'],
    body:
      'Taner Property en Taner Yapı İnşaat realiseren moderne woonruimten en commerciële gebouwen, van vastgoedontwikkeling tot bouw en van virtuele kantoren tot investeringen. Esthetiek, kwaliteit en vertrouwen op één lijn.',
    links: [
      { label: 'Taner Property', href: '#taner-property' },
      { label: 'Taner Yapı İnşaat', href: '#taner-yapi' },
    ],
    note: 'Beelden zijn illustratief en tonen geen specifiek project van het bedrijf.',
  },
  energy: {
    label: 'Energie en duurzaamheid',
    headline: ['Blijvende waarde', 'uit de zon.'],
    body:
      'TopGreen Solutions biedt milieuvriendelijke, efficiënte technologieën met zonne-energiesystemen, energieopslagbatterijen en oplossingen voor hernieuwbare energie.',
    bullets: ['Zonne-energiesystemen', 'Energieopslagbatterijen', 'Oplossingen voor hernieuwbare energie'],
    note: 'Beelden zijn illustratief.',
  },
  about: {
    label: 'Over ons',
    headline: ['Een familie met wortels.', 'Een geïntegreerde structuur.'],
    p1: 'Taner International Group is een familiebedrijf met meer dan 40 jaar geschiedenis. Met een internationale blik en een betrouwbare, professionele structuur biedt de groep sterke investeringsmogelijkheden in Turkije.',
    p2: 'Met de merken Taner Property, Taner Yapı İnşaat, Besutan, TopGreen Solutions en Opuze vormt de groep een geïntegreerde holding van vastgoed en energie tot bouw en een creatief bureau.',
    stat: { value: '40+', label: 'jaar familiegeschiedenis' },
    pillars: [
      { title: 'Familiebedrijf', text: 'Continuïteit in besluiten, vertrouwen in relaties.' },
      { title: 'Multidisciplinair', text: 'Vastgoed, bouw, energie en creatieve diensten.' },
      { title: 'Internationaal', text: 'Actief op de Turkse en de Nederlandse markt.' },
    ],
  },
  contact: {
    label: 'Contact en samenwerking',
    headline: ['Laten we de toekomst', 'samen bouwen.'],
    body: 'Neem contact met ons op over investeringsmogelijkheden en samenwerkingen.',
    emailLabel: 'E-mail',
    email: 'info@tannerinternational.com',
    locations: 'Turkije · Nederland',
    locationsLabel: 'Regio’s',
    cta: 'Stuur een e-mail',
    divisionsLabel: 'Activiteiten',
  },
  footer: {
    tagline: 'Investeringen, vastgoed, bouw en energie tussen Turkije en Nederland.',
    divisions: 'Merken',
    contact: 'Contact',
    language: 'Taal',
    rights: 'Alle rechten voorbehouden.',
    partner: 'Creative partner',
    illustrative: 'Fotografie is illustratief (Unsplash).',
  },
  a11y: {
    externalLink: 'opent in een nieuw tabblad',
    heroCanvas: 'Decoratieve driedimensionale scène',
    toTop: 'Terug naar boven',
    imgAlts: {
      'concrete-curve-light': 'Gebogen detail van een lichte betonnen gevel',
      'amsterdam-canal-day': 'Historische grachtenpanden in Amsterdam',
      'izmir-bay-aerial': 'Luchtfoto van de baai van İzmir en de waterkant',
      'izmir-clock-tower': 'De klokkentoren van İzmir op het Konakplein',
      'brick-residential': 'Modern woongebouw met bakstenen gevel',
      'building-under-construction': 'Een gebouw van meerdere verdiepingen in aanbouw',
      'amsterdam-canal-night': 'Amsterdamse grachtenpanden bij nacht',
      'solar-array': 'Zonnepanelen op een dak',
      'solar-aerial-parking': 'Luchtfoto van een terrein bedekt met zonnepanelen',
      'solar-building-aerial': 'Een gebouw met een dak vol zonnepanelen',
      'concrete-curve-bw': 'Gebogen betonarchitectuur, zwart-wit',
      'spiral-stairs-bw': 'Betonnen wenteltrap, zwart-wit',
      'curved-staircase-white': 'Witte gebogen trap',
      'minimal-staircase': 'Minimalistische witte betonnen trap',
      'facade-grid-bw': 'Betonnen gevelraster, zwart-wit',
      'brutalist-bw': 'Detail van een brutalistische betonnen gevel',
      'arches-hallway': 'Een lange gang met bogen',
      'rebar-detail': 'Detail van wapeningsstaal op een bouwplaats',
      'texture-concrete-steps': 'Textuur van betonnen treden',
      'black-concrete-building': 'Donker betonnen gebouw',
    },
  },
  status: {
    loading3d: 'De driedimensionale scène wordt geladen',
    noWebgl: 'Uw browser ondersteunt de 3D-scène niet; er wordt een statische weergave getoond.',
  },
}
