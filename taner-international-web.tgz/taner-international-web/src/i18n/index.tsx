import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type { Dictionary, Lang } from './types'
import { tr } from './tr'
import { en } from './en'
import { nl } from './nl'

export const LANGS: Lang[] = ['tr', 'en', 'nl']
export const DEFAULT_LANG: Lang = 'tr'
const STORAGE_KEY = 'taner-lang'
const SITE_URL = 'https://taner-international.com/'

const dictionaries: Record<Lang, Dictionary> = { tr, en, nl }

function isLang(v: unknown): v is Lang {
  return typeof v === 'string' && (LANGS as string[]).includes(v)
}

/** Initial language: explicit ?lang= param → stored choice → Turkish (default, never browser-detected). */
function detectInitial(): Lang {
  try {
    const param = new URLSearchParams(window.location.search).get('lang')
    if (isLang(param)) return param
    const stored = window.localStorage.getItem(STORAGE_KEY)
    if (isLang(stored)) return stored
  } catch {
    /* storage unavailable */
  }
  return DEFAULT_LANG
}

interface I18nValue {
  lang: Lang
  t: Dictionary
  setLang: (l: Lang) => void
}

const I18nContext = createContext<I18nValue | null>(null)

function setMeta(selector: string, attr: string, value: string) {
  let el = document.head.querySelector<HTMLMetaElement | HTMLLinkElement>(selector)
  if (!el) {
    const isLink = selector.startsWith('link')
    el = document.createElement(isLink ? 'link' : 'meta')
    const m = selector.match(/\[(\w+(?::\w+)?)="([^"]+)"\]/)
    if (m) el.setAttribute(m[1], m[2])
    document.head.appendChild(el)
  }
  el.setAttribute(attr, value)
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => detectInitial())

  const setLang = useCallback((l: Lang) => {
    setLangState(l)
    try {
      window.localStorage.setItem(STORAGE_KEY, l)
    } catch {
      /* ignore */
    }
  }, [])

  // Localised document metadata
  useEffect(() => {
    const d = dictionaries[lang]
    document.documentElement.lang = lang
    document.title = d.meta.title
    setMeta('meta[name="description"]', 'content', d.meta.description)
    setMeta('meta[property="og:title"]', 'content', d.meta.ogTitle)
    setMeta('meta[property="og:description"]', 'content', d.meta.description)
    setMeta('meta[property="og:locale"]', 'content', lang === 'tr' ? 'tr_TR' : lang === 'nl' ? 'nl_NL' : 'en_GB')
    setMeta('meta[name="twitter:title"]', 'content', d.meta.ogTitle)
    setMeta('meta[name="twitter:description"]', 'content', d.meta.description)
    setMeta('link[rel="canonical"]', 'href', lang === DEFAULT_LANG ? SITE_URL : `${SITE_URL}?lang=${lang}`)
  }, [lang])

  const value = useMemo<I18nValue>(() => ({ lang, t: dictionaries[lang], setLang }), [lang, setLang])
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}

export function useI18n(): I18nValue {
  const ctx = useContext(I18nContext)
  if (!ctx) throw new Error('useI18n must be used within I18nProvider')
  return ctx
}

export function useT(): Dictionary {
  return useI18n().t
}
