import { I18nProvider, useI18n } from './i18n'
import { Nav } from './components/Nav'
import { Hero } from './components/hero/Hero'
import { Corporate } from './components/sections/Corporate'
import { Bridge } from './components/sections/Bridge'
import { Divisions } from './components/sections/Divisions'
import { Investment } from './components/sections/Investment'
import { Architecture } from './components/sections/Architecture'
import { Energy } from './components/sections/Energy'
import { About } from './components/sections/About'
import { Contact } from './components/sections/Contact'
import { Footer } from './components/Footer'
import { useScrollMotion } from './hooks/useScrollMotion'

function Page() {
  const { lang } = useI18n()
  useScrollMotion([lang])
  return (
    <>
      <Nav />
      <main id="main">
        <Hero />
        <Corporate />
        <Bridge />
        <Divisions />
        <Investment />
        <Architecture />
        <Energy />
        <About />
        <Contact />
      </main>
      <Footer />
    </>
  )
}

export default function App() {
  return (
    <I18nProvider>
      <Page />
    </I18nProvider>
  )
}
