/** Resolves a public/ asset against the configured base URL (works at the site root and under sub-paths). */
export const asset = (path: string): string => `${import.meta.env.BASE_URL}${path.replace(/^\//, '')}`
