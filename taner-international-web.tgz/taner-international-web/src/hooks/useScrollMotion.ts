import { useEffect } from 'react'
import { gsap, ScrollTrigger, prefersReducedMotion } from '../lib/motion'

/**
 * Global scroll motion system:
 *  – [data-reveal]      fade/rise into view (staggered within a parent grid)
 *  – .pic--mask[data-mask]  clip-path image reveal
 *  – [data-parallax]    subtle vertical parallax on image inners
 *  – [data-parallax-bg] slower parallax for large section backgrounds
 *  – [data-spin]        slow rotation tied to scroll
 * Everything is skipped under prefers-reduced-motion (content stays fully visible via CSS).
 */
export function useScrollMotion(deps: unknown[] = []) {
  useEffect(() => {
    document.documentElement.classList.add('js')
    if (prefersReducedMotion()) {
      document.documentElement.classList.add('reduced-motion')
      return
    }
    const ctx = gsap.context(() => {
      // reveals
      gsap.utils.toArray<HTMLElement>('[data-reveal]').forEach((el) => {
        if (el.classList.contains('is-in')) return
        ScrollTrigger.create({
          trigger: el,
          start: 'top 92%',
          once: true,
          onEnter: () => {
            gsap.fromTo(
              el,
              { opacity: 0, y: 28 },
              {
                opacity: 1,
                y: 0,
                duration: 1.1,
                ease: 'power3.out',
                onComplete: () => {
                  el.classList.add('is-in')
                  gsap.set(el, { clearProps: 'transform,opacity' })
                },
              },
            )
          },
        })
      })
      // image masks
      gsap.utils.toArray<HTMLElement>('.pic--mask[data-mask]').forEach((el) => {
        if (el.classList.contains('is-in')) return
        gsap.fromTo(
          el,
          { clipPath: 'inset(0 0 100% 0)' },
          {
            clipPath: 'inset(0 0 0% 0)',
            duration: 1.4,
            ease: 'power4.out',
            scrollTrigger: { trigger: el, start: 'top 88%', once: true },
            onComplete: () => {
              el.classList.add('is-in')
              gsap.set(el, { clearProps: 'clipPath' })
            },
          },
        )
      })
      // parallax on image inners
      gsap.utils.toArray<HTMLElement>('[data-parallax]').forEach((el) => {
        gsap.fromTo(
          el,
          { yPercent: -5 },
          { yPercent: 5, ease: 'none', scrollTrigger: { trigger: el.parentElement, start: 'top bottom', end: 'bottom top', scrub: true } },
        )
      })
      gsap.utils.toArray<HTMLElement>('[data-parallax-bg]').forEach((el) => {
        gsap.fromTo(
          el,
          { yPercent: -8 },
          { yPercent: 8, ease: 'none', scrollTrigger: { trigger: el.parentElement, start: 'top bottom', end: 'bottom top', scrub: true } },
        )
      })
      gsap.utils.toArray<HTMLElement>('[data-spin]').forEach((el) => {
        gsap.fromTo(
          el,
          { rotate: -30 },
          { rotate: 30, ease: 'none', scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true } },
        )
      })
    })
    const refresh = () => ScrollTrigger.refresh()
    window.addEventListener('load', refresh)
    const id = window.setTimeout(refresh, 600)
    return () => {
      ctx.revert()
      window.removeEventListener('load', refresh)
      window.clearTimeout(id)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
}
