import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: './',
  build: {
    target: 'es2020',
    chunkSizeWarningLimit: 1000,
    rolldownOptions: {
      output: {
        advancedChunks: {
          groups: [
            { name: 'react', test: /node_modules\/(react|react-dom|scheduler)\// },
            { name: 'gsap', test: /node_modules\/gsap\// },
            { name: 'three', test: /node_modules\/three\// },
            { name: 'r3f', test: /node_modules\/(@react-three|react-reconciler|zustand|its-fine|suspend-react|react-use-measure|use-sync-external-store)\// },
          ],
        },
      },
    },
  },
})
