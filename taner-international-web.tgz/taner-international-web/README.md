# TANER INTERNATIONAL — Website

Premium corporate site for Taner International Group (Türkiye · Netherlands).
Single-page, Turkish by default, fully localised in English and Dutch, with a real-time WebGL hero.

## Stack

- React 19 + TypeScript + Vite
- Three.js via React Three Fiber (hero scene, lazy-loaded in its own chunk)
- GSAP + ScrollTrigger (scroll motion system)
- Custom CSS design system (`src/styles/global.css`) — no UI framework
- Manrope (variable, self-hosted via `@fontsource-variable/manrope`, OFL)

## Run

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # → dist/
npm run preview
```

QA helpers (headless Chromium, used during development):

```bash
node scripts/qa-shots.mjs qa          # screenshots desktop / tablet / mobile
node scripts/qa-functional.mjs qa     # language switching, links, fallback, reduced motion
```

## Structure

```
src/
  i18n/            dictionary-based localisation (tr.ts is the source of truth; en.ts, nl.ts mirror it)
  components/
    hero/          Hero, Headline (cursor-reactive wordmark), HeroScene (R3F globe), geo.ts
    sections/      Corporate, Bridge (TR–NL map), Divisions, Investment, Architecture, Energy, About, Contact
    Nav, Footer, Picture (responsive AVIF/WebP)
  hooks/           useScrollMotion (GSAP), useReducedMotion / useMediaQuery
  styles/          global.css — tokens, typography, sections
scripts/
  build-land.mjs       → public/data/land.bin   (dot-globe land points, Natural Earth 110m via world-atlas)
  build-map.mjs        → public/img/europe-dots*.png (section 03 map)
  optimize-images.mjs  → public/img/*-{640,1024,1440}.{webp,avif}
public/
  brand/           official Taner International logo (from taner-international.com) + Opuze logo (opuze.com)
  img/             optimised photography + maps
  data/            land.bin
```

## Localisation

- Default language is **Turkish**; never browser-detected. `?lang=en` / `?lang=nl` select a language explicitly,
  and the choice persists in `localStorage` (`taner-lang`).
- `document.title`, meta description, Open Graph, canonical and `<html lang>` update with the language.
- Add or change copy only in `src/i18n/*.ts`; components never contain literal UI text.

## Content & verification notes

All company facts come from https://taner-international.com (fetched October 2026):
"40 yılı aşkın köklü aile holdingi", five divisions with their published descriptions, locations "Türkiye · Hollanda",
İzmir for Taner Property, and the published e-mail address.

- **E-mail address**: the official site publishes `info@tannerinternational.com` (double "n"). It is used verbatim.
  Please confirm this is correct before launch — if the real mailbox is `info@taner-international.com`,
  change `contact.email` in the three dictionaries and the `email` field in `index.html` (JSON-LD).
- No founding year is published → no timeline is shown.
- No websites were found for Taner Property, Taner Yapı İnşaat, Besutan Limited or TopGreen Solutions → they are not linked.
  Add a `url` to the item in each dictionary to turn a row into a link.
- The official site's privacy-policy link points to `#` (no policy published) → no legal links are shown. Add them to the footer when available.
- The geographic markers are the Netherlands (Amsterdam coordinates as the country anchor) and İzmir, Türkiye. No office locations are implied.
- Photography is illustrative stock from Unsplash (Unsplash License) and is labelled as such; it does not depict company projects.
  Source IDs are in `scripts/optimize-images.mjs`.

## Accessibility & performance

- Accessible `<h1>` for the wordmark; all effect layers are `aria-hidden`.
- `prefers-reduced-motion`: scroll animations, parallax, globe idle motion and cursor effects are disabled; content is fully visible.
- WebGL unavailable or crashing → static SVG/gradient fallback (`Fallback` in `Hero.tsx`), never blocks text or navigation.
- Hero 3D bundle (three + r3f, ~245 kB gzip) is lazy-loaded after first paint and pauses rendering when scrolled out of view.
  Mobile/coarse pointers use fewer points, lower DPR and no fresnel pass.
- Images: AVIF/WebP, `srcset`/`sizes`, lazy below the fold, explicit dimensions (no CLS).

## Deploy

Static output (`dist/`) — host on any static host (Netlify, Vercel, Cloudflare Pages, Nginx).
`base` is `./` so it also works under a sub-path. Set the canonical domain in `index.html` and `src/i18n/index.tsx` (`SITE_URL`) if it changes.
